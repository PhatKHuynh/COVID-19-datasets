#START UP [Tables]
library(tidyverse)
library(lubridate)
library(qwraps2)
library(gt)
library(gtsummary)

#Define markup language
options(qwraps2_markup = "markdown")

#Load data
hcovidfull <- read.csv("data/hcovid_clean.csv", header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)

#Initialise
##data frame formation for tables
hcovidcomp <- hcovidfull %>% filter(CompOut == TRUE)
hcovidsi <- hcovidfull %>% filter(CompSI == TRUE)
hcovidhosp <- hcovidfull %>% filter(CompHosp == TRUE)
hcovidlondon <- hcovidfull %>% filter(London == TRUE)

hcovidtest <- hcovidfull %>% filter(TestOutcome !="Untested") #not required for composites
hcovidpos <- hcovidtest %>% filter(CompPosi == TRUE)



#Build summary format for qwraps2
summary_format <-
  list("Age (years)" =
         list("mean (SD)" = ~ qwraps2::mean_sd(.data$Age, digits = getOption("qwraps2_frmt_digits", 1), denote_sd = "paren")),
       "Sex" =
         list("Female" = ~ qwraps2::n_perc(.data$Sex == "Female", digits = 1, show_symbol = TRUE),
              "Male" =  ~ qwraps2::n_perc(.data$Sex == "Male", digits = 1,  show_symbol = TRUE)),
       "Ethnic Group" =
         list(`Asian or Asian British` = ~ qwraps2::n_perc(.data$EthnicMain == "Asian or Asian British", digits = 1, show_symbol = TRUE),
              `Black, African, Black British or Caribbean` = ~ qwraps2::n_perc(.data$EthnicMain == "Black, African, Black British or Caribbean", digits = 1, show_symbol = TRUE),
              `Mixed or multiple ethnic groups` = ~ qwraps2::n_perc(.data$EthnicMain == "Mixed or multiple ethnic groups", digits = 1, show_symbol = TRUE),
              `White` = ~ qwraps2::n_perc(.data$EthnicMain == "White", digits = 1, show_symbol = TRUE),
              `Another ethnic group` = ~ qwraps2::n_perc(.data$EthnicMain == "Another ethnic group", digits = 1, show_symbol = TRUE),
              `Prefer not to say` = ~ qwraps2::n_perc(.data$EthnicMain == "Prefer not to say", digits = 1, show_symbol = TRUE)),
       "Household - Persons" =
         list(`Lives alone` = ~ qwraps2::n_perc(.data$hHousehold == "I live alone", digits = 1, show_symbol = TRUE),
              `Lives with 1 or more persons` = ~ qwraps2::n_perc(.data$hHousehold == "I live with 1 or more persons", digits = 1, show_symbol = TRUE)),
       "Household - Children" =
         list(`No Children` = ~ qwraps2::n_perc(na.omit(.data$hChildren) %in% "No", digits = 1, show_symbol = TRUE),
              `Has children` = ~ qwraps2::n_perc(na.omit(.data$hChildren) %in% "Yes", digits = 1, show_symbol = TRUE)),
       "Comorbidities" =
         list("Hypertension" = ~ qwraps2::n_perc(na.omit(.data$Hypertension) == TRUE, digits = 1, show_symbol = TRUE),
              "Diabetes" = ~ qwraps2::n_perc(na.omit(.data$Diabetes) == TRUE, digits = 1, show_symbol = TRUE),
              "Cancer" = ~ qwraps2::n_perc(na.omit(.data$Cancer) == TRUE, digits = 1, show_symbol = TRUE),
              "Heart disease" = ~ qwraps2::n_perc(na.omit(.data$`Heart disease`) == TRUE, digits = 1, show_symbol = TRUE),
              "Immunosuppression" = ~ qwraps2::n_perc(na.omit(.data$Immunosuppression) == TRUE, digits = 1, show_symbol = TRUE),
              "Respiratory disease" = ~ qwraps2::n_perc(na.omit(.data$`Respiratory disease`) == TRUE, digits = 1, show_symbol = TRUE),
              "Renal disease" = ~ qwraps2::n_perc(na.omit(.data$`Renal disease`) == TRUE, digits = 1, show_symbol = TRUE),
              "Liver disease" = ~ qwraps2::n_perc(na.omit(.data$`Liver disease`) == TRUE, digits = 1, show_symbol = TRUE),
              "Neurological disease" = ~ qwraps2::n_perc(na.omit(.data$`Neurological disease`) == TRUE, digits = 1, show_symbol = TRUE),
              "Obesity" = ~ qwraps2::n_perc(na.omit(.data$Obesity) == TRUE, digits = 1, show_symbol = TRUE),
              "None of the above" = ~ qwraps2::n_perc(na.omit(.data$`No comorbidities`) == TRUE, digits = 1, show_symbol = TRUE),
              "Prefer not to say" = ~ qwraps2::n_perc(na.omit(.data$`Prefer not to say`) == TRUE, digits = 1, show_symbol = TRUE)),
       "Tobacco Smoking" =
         list("Current or Ex-smoker within 1 year" = ~ qwraps2::n_perc(na.omit(.data$Smoker) == "Current smoker or Ex-smoker (within 1 year)", digits = 1, show_symbol = TRUE),
              "Ex-smoker >1 year" = ~ qwraps2::n_perc(na.omit(.data$Smoker) == "Ex-smoker (more than 1 year)", digits = 1, show_symbol = TRUE),
              "Never smoked" = ~ qwraps2::n_perc(na.omit(.data$Smoker) == "Never smoked", digits = 1, show_symbol = TRUE),
              "Prefer not to say" = ~ qwraps2::n_perc(na.omit(.data$Smoker) == "Prefer not to say", digits = 1, show_symbol = TRUE))
  )

#Output individual summary tables
hcovidfull_ST <- summary_table(hcovidfull, summary_format)
hcovidcomp_ST <- summary_table(hcovidcomp, summary_format)
hcovidsi_ST <- summary_table(hcovidsi, summary_format)
hcovidhosp_ST <- summary_table(hcovidhosp, summary_format)
hcovidtest_ST <- summary_table(hcovidtest, summary_format)
hcovidpos_ST <- summary_table(hcovidpos, summary_format)

#Combine summary tables --> ALL, SELF-ISOLATED, COVID-19 POS+
hcovid_ST_FINAL <- cbind(hcovidfull_ST, hcovidcomp_ST, hcovidsi_ST, hcovidhosp_ST, hcovidpos_ST)


#gt Summary Table
##initialise
hcovid_ST_FINAL <- as.data.frame(hcovid_ST_FINAL)
hcovid_ST_FINAL <- rownames_to_column(hcovid_ST_FINAL, "rownames")
hcovid_ST_FINAL <- hcovid_ST_FINAL %>%
  mutate(rownames = c("years, mean (SD)", "Female", "Male", "Asian or Asian British", "Black, African, Black British or Caribbean", "Mixed or multiple ethnic groups", "White", "Another ethnic group", "Prefer not to say", "Lives alone", "Lives with 1 or more persons", "No Children", "Has children", "Hypertension", "Diabetes", "Cancer", "Heart disease", "Immunosuppression", "Respiratory disease", "Renal disease", "Liver disease", "Neurological disease", "Obesity", "None of the above", "Prefer not to say", "Current or Ex-smoker within 1 year", "Ex-smoker > 1 year", "Never smoked", "Prefer not to say")) %>% 
  mutate(groups = c(
    "Age",
    rep("Sex", times = 2),
    rep("Ethnic group", times = 6),
    rep("Household - Persons", times = 2),
    rep("Household - Children", times = 2),
    rep("Comorbidities", times = 12),
    rep("Tobacco smoking status", times = 4)))

##create gt table for each outcome and composite
gt_hcovid_summary <- hcovid_ST_FINAL %>% 
  gt(groupname_col = "groups") %>%
  tab_header(
    title = "Table 1. Sociodemographics",
    subtitle = "n (%), unless otherwise stated"
  ) %>%
  tab_stubhead(label = "") %>% 
  cols_label(
    rownames = "",
    `hcovidfull (N = 6,152)` = md("**All**<sup>1</sup>  
                                  (n = 6152)"),
    `hcovidcomp (N = 1,806)` = md("**COVID-19 Composite Endpoint**<sup>1</sup>  
                                  (n = 1806)"),
    `hcovidsi (N = 1,776)` = md("**Self-isolated**<sup>2</sup>  
                                (n = 1776)"),
    `hcovidhosp (N = 49)` = md("**Hospitalised**<sup>3</sup>  
                               (n = 49)"),
    `hcovidpos (N = 459)` = md("**COVID-19 pos+**<sup>4</sup>  
                               (n = 459)")) %>% 
  tab_source_note(
    source_note = md("<sup>1</sup>All respondents  
                     <sup>2</sup>Participants with the presence of the COVID-19 composite endpoint    
                     <sup>3</sup>Participants who self-isolated due to symptoms and/or testing positive for SARS-CoV-2  
                     <sup>4</sup>Participants who were hospitalised due to suspected/confirmed COVID-19  
                     <sup>5</sup>Participants who have tested positive for SARS-CoV-2")) %>%
  tab_options(heading.align = "left") %>% 
  tab_style(
    style = cell_text(style = "italic", indent = pct(2.5)),
    locations = cells_body(columns = vars(rownames))) %>%
  cols_align(align = "center", columns = vars("hcovidfull (N = 6,152)", "hcovidcomp (N = 1,806)", "hcovidsi (N = 1,776)", "hcovidhosp (N = 49)", "hcovidpos (N = 459)"))


#Initialise specialty and grade tables for gt
##create data frames for doctors and non-doctors
hcoviddocs <- filter(hcovidfull, Role == "Doctor")
hcovidnondocs <- filter(hcovidfull, Role != "Doctor")

##doctors df
DocSpecialty <- merge(as.data.frame(table(hcoviddocs$PSDoc)), as.data.frame(round(prop.table(table(hcoviddocs$PSDoc))*100, digits = 1)), by = "Var1")
colnames(DocSpecialty) <- c("Specialty", "n", "%")

DocGrade <- merge(as.data.frame(table(hcoviddocs$Grade)), as.data.frame(round(prop.table(table(hcoviddocs$Grade))*100, digits = 1)), by = "Var1")
colnames(DocGrade) <- c("Grade", "n", "%")

##non-doctors df
NonDocSpecialty <- merge(as.data.frame(table(hcovidnondocs$PSMinor)), as.data.frame(round(prop.table(table(hcovidnondocs$PSMinor))*100, digits = 1)), by = "Var1")
colnames(NonDocSpecialty) <- c("Specialty", "n", "%")

NonDocGrade <- merge(as.data.frame(table(hcovidnondocs$Grade)), as.data.frame(round(prop.table(table(hcovidnondocs$Grade))*100, digits = 1)), by = "Var1")
colnames(NonDocGrade) <- c("Grade", "n", "%")


#Create gt tables for specialties and grades for doctors and non-doctors
##doctors
gt_DocSpecialty <- DocSpecialty %>%  
  gt() %>%
  tab_header(
    title = "eTable 1. Doctors by specialty",
  ) %>%
  tab_options(heading.align = "left") %>% 
  cols_align(align = "left", columns = vars("Specialty")) %>% 
  cols_align(align = "right", columns = vars("n", "%"))

gt_DocGrade <- DocGrade %>%  
  gt() %>%
  tab_header(
    title = "eTable 2. Doctors by grade",
  ) %>%
  tab_options(heading.align = "left") %>% 
  cols_align(align = "left", columns = vars("Grade")) %>% 
  cols_align(align = "right", columns = vars("n", "%"))

##non-doctors
gt_NonDocSpecialty <- NonDocSpecialty %>%  
  gt() %>%
  tab_header(
    title = "eTable 3. Non-doctors by specialty",
  ) %>%
  tab_options(heading.align = "left") %>% 
  cols_align(align = "left", columns = vars("Specialty")) %>% 
  cols_align(align = "right", columns = vars("n", "%"))

gt_NonDocGrade <- NonDocGrade %>%  
  gt() %>%
  tab_header(
    title = "eTable 4. Non-doctors by grade",
  ) %>%
  tab_options(heading.align = "left") %>% 
  cols_align(align = "left", columns = vars("Grade")) %>% 
  cols_align(align = "right", columns = vars("n", "%"))


#TIME OUT  
print(gt_hcovid_summary)
print(gt_DocSpecialty)
print(gt_DocGrade)
print(gt_NonDocSpecialty)
print(gt_NonDocGrade)


#DEFORMATION