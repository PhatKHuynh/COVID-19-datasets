#START UP [Tables]
library(tidyverse)
library(lubridate)
library(qwraps2)
library(gt) #tables


#Define markup language
options(qwraps2_markup = "markdown")

#Load data
hcovidfull <- read.csv("data/hcovid_clean.csv", header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)

#Initialise
##data frame formation for tables
hcovidsi <- hcovidfull %>% filter(CompSI == TRUE)
hcovidhosp <- hcovidfull %>% filter(CompHosp == TRUE)
hcovidpos <- hcovidfull %>% filter(CompPosi == TRUE)
hcovidcompout <- hcovidfull %>% filter(CompOut == TRUE)


#Build summary format - n
summary_n <-
  list("Age (years)" =
         list("mean (SD)" = ~ qwraps2::mean_sd(.data$Age, digits = getOption("qwraps2_frmt_digits", 1), denote_sd = "paren")),
       "Sex" =
         list("Male" = ~ sum(.data$Sex == "Male"),
              "Female" = ~ sum(.data$Sex == "Female")),
       "Ethnic Group" =
         list(`White` = ~ sum(na.omit(.data$EthnicBAME == "White")),
              `BAME` = ~ sum(na.omit(.data$EthnicBAME == "BAME")),
              "Prefer not to say" = ~ sum(na.omit(.data$EthnicBAME == "Prefer not to say"))),
       "Household" =
         list(`Lives alone` = ~ sum(.data$hChildrenDef == "Lives alone"),
              `Lives with 1 or more persons; no children` = ~ sum(.data$hChildrenDef == "No children"),
              `Lives with 1 or more persons; has children` = ~ sum(.data$hChildrenDef == "Has children")),
       "Comorbidities" =
         list("Hypertension" = ~ sum(na.omit(.data$Hypertension == TRUE)),
              "Diabetes" = ~ sum(na.omit(.data$Diabetes == TRUE)),
              "Cancer" = ~ sum(na.omit(.data$Cancer == TRUE)),
              "Heart disease" = ~ sum(na.omit(.data$`Heart disease` == TRUE)),
              "Immunosuppression" = ~ sum(na.omit(.data$Immunosuppression == TRUE)),
              "Respiratory disease" = ~ sum(na.omit(.data$`Respiratory disease` == TRUE)),
              "Renal disease" = ~ sum(na.omit(.data$`Renal disease` == TRUE)),
              "Liver disease" = ~ sum(na.omit(.data$`Liver disease` == TRUE)),
              "Neurological disease" = ~ sum(na.omit(.data$`Neurological disease` == TRUE)),
              "Obesity" = ~ sum(na.omit(.data$Obesity == TRUE)),
              "Prefer not to say" = ~ sum(na.omit(.data$`Prefer not to say` == "Two or more"))),
       "Tobacco Smoking" =
         list("Never smoked" = ~ sum(na.omit(.data$Smoker == "Never smoked")),
              "Current or Ex-smoker within 1 year" = ~ sum(na.omit(.data$Smoker == "Current smoker or Ex-smoker (within 1 year)")),
              "Ex-smoker >1 year" = ~ sum(na.omit(.data$Smoker == "Ex-smoker (more than 1 year)")),
              "Prefer not to say" = ~ sum(na.omit(.data$Smoker == "Prefer not to say"))),
       "Country" =
         list("England" = ~ sum(.data$Country == "England"),
              "Northern Ireland" = ~ sum(.data$Country == "Northern Ireland"),
              "Scotland" = ~ sum(.data$Country == "Scotland"),
              "Wales" = ~ sum(.data$Country == "Wales")),
       "Main Healthcare Facility" =
         list("Hospital" = ~ sum(.data$Facility == "Hospital"),
              "Community healthcare facility" = ~ sum(.data$Facility == "Community healthcare facility"),
              "Social care facility" = ~ sum(.data$Facility == "Social care facility"),
              "Other" = ~ sum(.data$Facility == "Other")),
       "Role Group" = 
         list("Nurses, midwives and associated staff" = ~ sum(.data$RoleGroup == "Nurses, midwives and associated staff"),
              "AHPs" = ~ sum(.data$RoleGroup == "AHPs"),
              "Dentists and dental staff" = ~ sum(.data$RoleGroup == "Dentists and dental staff"),
              "Doctors" = ~ sum(.data$RoleGroup == "Doctors"),
              "Other" = ~ sum(.data$RoleGroup == "Other")),
       "Public Transport to work" =
         list("No" = ~sum(.data$PublicTransport == "No"),
              "Yes" = ~sum(.data$PublicTransport == "Yes")),
       "Regular clinical contact with COVID-19 patients" =
         list("No" = ~sum(.data$contactCOVID == "No"),
              "Yes" = ~sum(.data$contactCOVID == "Yes")),
       "Regular exposure to AGP(s) performed in COVID-19 patients" =
         list("No" = ~sum(.data$AGPExpo == "No"),
              "Yes" = ~sum(.data$AGPExpo == "Yes")),
       "Sufficent training in PPE usage" =
         list("No" = ~sum(.data$PPETraining == "No"),
              "Yes" = ~sum(.data$PPETraining == "Yes")),
       "Lacked access to PPE items for clinical contact" =
         list("No" = ~sum(.data$PPELack == "No"),
              "Yes" = ~sum(.data$PPELack == "Yes")),
       "Clinical contact without adequate PPE" =
         list("Never" = ~sum(.data$NoPPEexpofreq == "Never"),
              "Rarely" = ~sum(.data$NoPPEexpo == "Rarely"),
              "Sometimes" = ~sum(.data$NoPPEexpofreq == "Sometimes"),
              "Often" = ~sum(.data$NoPPEexpofreq == "Often"),
              "Always" = ~sum(.data$NoPPEexpofreq == "Always")),
       "Reuse disposable PPE" =
         list("No" = ~ sum(.data$ReusePPE == "No"),
              "Yes" = ~ sum(.data$ReusePPE == "Yes")),
       "Used improvised PPE" =
         list("No" = ~ sum(.data$CustomPPE == "No"),
              "Yes" = ~ sum(.data$CustomPPE == "Yes"))
  )


#Build summary format - %
summary_perc <-
  list("Age (years)" =
         list("mean (SD)" = ~ qwraps2::mean_sd(.data$Age, digits = getOption("qwraps2_frmt_digits", 1), denote_sd = "paren")),
       "Sex" =
         list("Male" = ~ round(sum(.data$Sex == "Male")*100/nrow(hcovidfull), digits = 1),
              "Female" = ~ round(sum(.data$Sex == "Female")*100/nrow(hcovidfull), digits = 1)),
       "Ethnic Group" =
         list(`White` = ~ round(sum(.data$EthnicBAME == "White", na.rm = TRUE)*100/nrow(hcovidfull), digits = 1),
              `BAME` = ~ round(sum(.data$EthnicBAME == "BAME", na.rm = TRUE)*100/nrow(hcovidfull), digits = 1),
              `Prefer not to say` = ~ round(sum(.data$EthnicBAME == "Prefer not to say", na.rm = TRUE)*100/nrow(hcovidfull), digits = 1)),
       "Household" =
         list(`Lives alone` = ~ round(sum(.data$hChildrenDef == "Lives alone")*100/nrow(hcovidfull), digits = 1),
              `Lives with 1 or more persons; no children` = ~ round(sum(.data$hChildrenDef == "No children")*100/nrow(hcovidfull), digits = 1),
              `Lives with 1 or more persons; has children` = ~ round(sum(.data$hChildrenDef == "Has children")*100/nrow(hcovidfull), digits = 1)),
       "Comorbidities" =
         list("Hypertension" = ~ round(sum(na.omit(.data$Hypertension == TRUE))*100/nrow(hcovidfull), digits = 1),
              "Diabetes" = ~ round(sum(na.omit(.data$Diabetes == TRUE))*100/nrow(hcovidfull), digits = 1),
              "Cancer" = ~ round(sum(na.omit(.data$Cancer == TRUE))*100/nrow(hcovidfull), digits = 1),
              "Heart disease" = ~ round(sum(na.omit(.data$`Heart disease` == TRUE))*100/nrow(hcovidfull), digits = 1),
              "Immunosuppression" = ~ round(sum(na.omit(.data$Immunosuppression == TRUE))*100/nrow(hcovidfull), digits = 1),
              "Respiratory disease" = ~ round(sum(na.omit(.data$`Respiratory disease` == TRUE))*100/nrow(hcovidfull), digits = 1),
              "Renal disease" = ~ round(sum(na.omit(.data$`Renal disease` == TRUE))*100/nrow(hcovidfull), digits = 1),
              "Liver disease" = ~ round(sum(na.omit(.data$`Liver disease` == TRUE))*100/nrow(hcovidfull), digits = 1),
              "Neurological disease" = ~ round(sum(na.omit(.data$`Neurological disease` == TRUE))*100/nrow(hcovidfull), digits = 1),
              "Obesity" = ~ round(sum(na.omit(.data$Obesity == TRUE))*100/nrow(hcovidfull), digits = 1),
              "Prefer not to say" = ~ round(sum(na.omit(.data$`Prefer not to say` == TRUE))*100/nrow(hcovidfull), digits = 1)),
       "Tobacco Smoking" =
         list("Never smoked" = ~ round(sum(na.omit(.data$Smoker == "Never smoked"))*100/nrow(hcovidfull), digits = 1),
              "Current or Ex-smoker within 1 year" = ~ round(sum(na.omit(.data$Smoker == "Current smoker or Ex-smoker (within 1 year)"))*100/nrow(hcovidfull), digits = 1),
              "Ex-smoker >1 year" = ~ round(sum(na.omit(.data$Smoker == "Ex-smoker (more than 1 year)"))*100/nrow(hcovidfull), digits = 1),
              "Prefer not to say" = ~ round(sum(na.omit(.data$Smoker == "Prefer not to say"))*100/nrow(hcovidfull), digits = 1)),
       "Country" =
         list("England" = ~ round(sum(.data$Country == "England")*100/nrow(hcovidfull), digits = 1),
              "Northern Ireland" = ~ round(sum(.data$Country == "Northern Ireland")*100/nrow(hcovidfull), digits = 1),
              "Scotland" = ~ round(sum(.data$Country == "Scotland")*100/nrow(hcovidfull), digits = 1),
              "Wales" = ~ round(sum(.data$Country == "Wales")*100/nrow(hcovidfull), digits = 1)),
       "Main Healthcare Facility" =
         list("Hospital" = ~ round(sum(.data$Facility == "Hospital")*100/nrow(hcovidfull), digits = 1),
              "Community healthcare facility" = ~ round(sum(.data$Facility == "Community healthcare facility")*100/nrow(hcovidfull), digits = 1),
              "Social care facility" = ~ round(sum(.data$Facility == "Social care facility")*100/nrow(hcovidfull), digits = 1),
              "Other" = ~ round(sum(.data$Facility == "Other")*100/nrow(hcovidfull), digits = 1)),
       "Role Group" = 
         list("Nurses, midwives and associated staff" = ~ round(sum(.data$RoleGroup == "Nurses, midwives and associated staff")*100/nrow(hcovidfull), digits = 1),
              "AHPs" = ~ round(sum(.data$RoleGroup == "AHPs")*100/nrow(hcovidfull), digits = 1),
              "Dentists and dental staff" = ~ round(sum(.data$RoleGroup == "Dentists and dental staff")*100/nrow(hcovidfull), digits = 1),
              "Doctors" = ~ round(sum(.data$RoleGroup == "Doctors")*100/nrow(hcovidfull), digits = 1),
              "Other" = ~ round(sum(.data$RoleGroup == "Other")*100/nrow(hcovidfull), digits = 1)),
       "Public Transport to work" =
         list("No" = ~ round(sum(.data$PublicTransport == "No")*100/nrow(hcovidfull), digits = 1),
              "Yes" = ~ round(sum(.data$PublicTransport == "Yes")*100/nrow(hcovidfull), digits = 1)),
       "Regular clinical contact with COVID-19 patients" =
         list("No" = ~ round(sum(.data$contactCOVID == "No")*100/nrow(hcovidfull), digits = 1),
              "Yes" = ~ round(sum(.data$contactCOVID == "Yes")*100/nrow(hcovidfull), digits = 1)),
       "Regular exposure to AGP(s) performed in COVID-19 patients" =
         list("No" = ~ round(sum(.data$AGPExpo == "No")*100/nrow(hcovidfull), digits = 1),
              "Yes" = ~ round(sum(.data$AGPExpo == "Yes")*100/nrow(hcovidfull), digits = 1)),
       "Sufficent training in PPE usage" =
         list("No" = ~ round(sum(.data$PPETraining == "No")*100/nrow(hcovidfull), digits = 1),
              "Yes" = ~ round(sum(.data$PPETraining == "Yes")*100/nrow(hcovidfull), digits = 1)),
       "Lacked access to PPE items for clinical contact" =
         list("No" = ~ round(sum(.data$PPELack == "No")*100/nrow(hcovidfull), digits = 1),
              "Yes" = ~ round(sum(.data$PPELack == "Yes")*100/nrow(hcovidfull), digits = 1)),
       "Clinical contact without adequate PPE" =
         list("Never" = ~ round(sum(.data$NoPPEexpofreq == "Never")*100/nrow(hcovidfull), digits = 1),
              "Rarely" = ~ round(sum(.data$NoPPEexpofreq == "Rarely")*100/nrow(hcovidfull), digits = 1),
              "Sometimes" = ~ round(sum(.data$NoPPEexpofreq == "Sometimes")*100/nrow(hcovidfull), digits = 1),
              "Often" = ~ round(sum(.data$NoPPEexpofreq == "Often")*100/nrow(hcovidfull), digits = 1),
              "Always" = ~ round(sum(.data$NoPPEexpofreq == "Always")*100/nrow(hcovidfull), digits = 1)),
          "Reuse disposable PPE" =
         list("No" = ~ round(sum(.data$ReusePPE == "No")*100/nrow(hcovidfull), digits = 1),
              "Yes" = ~ round(sum(.data$ReusePPE == "Yes")*100/nrow(hcovidfull), digits = 1)),
       "Used improvised PPE" =
         list("No" = ~ round(sum(.data$CustomPPE == "No")*100/nrow(hcovidfull), digits =1),
              "Yes" = ~ round(sum(.data$CustomPPE == "Yes")*100/nrow(hcovidfull), digits =1))
  )


#Output summary tables
hcovidcompsi_ST_n <- summary_table(hcovidsi, summary_n)
hcovidcompsi_ST_perc <- summary_table(hcovidsi, summary_perc)

hcovidcomphosp_ST_n <- summary_table(hcovidhosp, summary_n)
hcovidcomphosp_ST_perc <- summary_table(hcovidhosp, summary_perc)

hcovidcomppos_ST_n <- summary_table(hcovidpos, summary_n)
hcovidcomppos_ST_perc <- summary_table(hcovidpos, summary_perc)

hcovidcompout_ST_n <- summary_table(hcovidcompout, summary_n)
hcovidcompout_ST_perc <- summary_table(hcovidcompout, summary_perc)


#Combine summary tables --> CompSI, CompHosp, CompPos, CompOut
hcovidcomp_FINAL <- cbind(hcovidcompsi_ST_n, hcovidcompsi_ST_perc, hcovidcomphosp_ST_n, hcovidcomphosp_ST_perc, hcovidcomppos_ST_n, hcovidcomppos_ST_perc, hcovidcompout_ST_n, hcovidcompout_ST_perc)


#gt for Table: Outcomes & Composite Outcome Summary
#Initialise
hCOVcomp <- as.data.frame(hcovidcomp_FINAL)

names(hCOVcomp)[1] <- "Self-isolation (n)"
names(hCOVcomp)[2] <- "Self-isolation (%)"
names(hCOVcomp)[3] <- "Hospitalised (n)"
names(hCOVcomp)[4] <- "Hospitalised (%)"
names(hCOVcomp)[5] <- "COVID-19 positive (n)"
names(hCOVcomp)[6] <- "COVID-19 positive (%)"
names(hCOVcomp)[7] <- "COVID-19 composite (n)"
names(hCOVcomp)[8] <- "COVID-19 composite (%)"

hCOVcomp <- rownames_to_column(hCOVcomp, "rownames")

hCOVcomp <- hCOVcomp %>% 
  mutate(rownames = c("mean (SD)", "Male", "Female", "White", "BAME", "Prefer not to say", "Lives alone", "Lives with 1 or more persons; no children", "Lives with 1 or more persons; has children", "Hypertension", "Diabetes", "Cancer", "Heart disease", "Immunosuppression", "Respiratory disease", "Renal disease", "Liver disease", "Neurological disease", "Obesity", "Prefer not to say", "Never smoked", "Current or Ex-smoker within 1 year", "Ex-smoker > 1 year", "Prefer not to say", "England", "Northern Ireland", "Scotland", "Wales", "Hospital", "Community healthcare facility", "Social care facility", "Other", "Nurses, midwives and associated staff", "AHPs", "Dentists and dental staff", "Doctors", "Other", "No", "Yes", "No", "Yes", "No", "Yes", "No", "Yes", "No", "Yes", "Never", "Rarely", "Sometimes", "Often", "Always", "No", "Yes", "No", "Yes")) %>% 
  mutate(groups = c(
    "Age",
    rep("Sex", times = 2),
    rep("Ethnicity", times = 3),
    rep("Household", times = 3),
    rep("Comorbidities", times = 11),
    rep("Smoking status", times = 4),
    rep("Country", times = 4),
    rep("Main Healthcare Facility", times = 4),
    rep("Role Group", times = 5),
    rep("Public Transport to travel to work", times = 2),
    rep("Regular clinical contact with COVID-19 patients", times =2),
    rep("Regular exposure to AGP(s) performed in COVID-19 patients", times = 2),
    rep("Sufficient training in PPE usage", times = 2),
    rep("Lacked access to PPE items for clinical contact", times = 2),
    rep("Clinical contact without adequate PPE", times = 5),
    rep("Reused disposable PPE", times = 2),
    rep("Used improvised PPE", times = 2)))

#Create gt table for each outcome and composite
gthCOVcomp <- hCOVcomp %>% 
  gt(groupname_col = "groups") %>%
  tab_header(
    title = "eTable 5. Outcomes and composite summary",
    subtitle = md("% out of all respondents (= 6152)")
  ) %>%
  tab_stubhead(label = "") %>% 
  tab_spanner(
    label = "Self-isolation",
    columns = vars(`Self-isolation (n)`, `Self-isolation (%)`)
  ) %>%
  tab_spanner(
    label = "Hospitalised",
    columns = vars(`Hospitalised (n)`, `Hospitalised (%)`)
  ) %>%
  tab_spanner(
    label = "COVID-19 pos+",
    columns = vars(`COVID-19 positive (n)`, `COVID-19 positive (%)`)
  ) %>%
  tab_spanner(
    label = md("**COVID-19 Composite**"),
    columns = vars(`COVID-19 composite (n)`, `COVID-19 composite (%)`)
  ) %>%
  cols_label(
    rownames = "",
    `Self-isolation (n)` = "n",
    `Self-isolation (%)` = "%",
    `Hospitalised (n)` = "n",
    `Hospitalised (%)` = "%",
    `COVID-19 positive (n)` = "n",
    `COVID-19 positive (%)` = "%",
    `COVID-19 composite (n)` = "n",
    `COVID-19 composite (%)` = "%"
  ) %>% 
  cols_align(align = "center", columns = vars(`Self-isolation (n)`, `Self-isolation (%)`, `Hospitalised (n)`, `Hospitalised (%)`, `COVID-19 positive (n)`, `COVID-19 positive (%)`, `COVID-19 composite (n)`, `COVID-19 composite (%)`)) %>%
  tab_options(heading.align = "left") %>% 
  tab_style(
    style = cell_text(style = "italic", indent = pct(2.5)),
    locations = cells_body(columns = vars(rownames)))

#TIME OUT
print(gthCOVcomp)


#DEFORMATION