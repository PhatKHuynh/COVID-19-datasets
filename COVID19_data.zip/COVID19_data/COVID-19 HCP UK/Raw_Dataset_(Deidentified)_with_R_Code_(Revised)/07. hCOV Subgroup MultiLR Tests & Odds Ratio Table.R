#START UP [Statistical Analyses]
library(tidyverse)
library(lubridate)
library(pROC)
library(jtools) #customised summary of glm tables
library(qwraps2) #tables
library(gt) #tables


#Define markup language
options(qwraps2_markup = "markdown")

#Load data
hcovidfull <- read.csv("data/hcovid_clean.csv", header = TRUE, check.names = FALSE, stringsAsFactors = FALSE)

#Initialise
##convert relevant vectors to factors and re-order/relevel
hcovidfull$EthnicMain <- as.factor(hcovidfull$EthnicMain)
hcovidfull$EthnicMain <- relevel(hcovidfull$EthnicMain, "White")

hcovidfull$EthnicBAME <- as.factor(hcovidfull$EthnicBAME)
hcovidfull$EthnicBAME <- factor(hcovidfull$EthnicBAME, levels = c("White", "BAME", "Prefer not to say"))

hcovidfull$hChildrenDef <- as.factor(hcovidfull$hChildrenDef)
hcovidfull$hChildrenDef <- factor(hcovidfull$hChildrenDef, levels = c("Lives alone", "No children", "Has children"))

hcovidfull$Smoker <- as.factor(hcovidfull$Smoker)
hcovidfull$Smoker <- factor(hcovidfull$Smoker, levels = c("Never smoked", "Current smoker or Ex-smoker (within 1 year)", "Ex-smoker (more than 1 year)", "Prefer not to say")) 

hcovidfull$RoleGroup <- as.factor(hcovidfull$RoleGroup)
hcovidfull$RoleGroup <- relevel(hcovidfull$RoleGroup, "Nurses, midwives and associated staff")

hcovidfull$Grade <- as.factor(hcovidfull$Grade)
hcovidfull$Grade <- relevel(hcovidfull$Grade, "Consultant")

hcovidfull$PSDoc <- as.factor(hcovidfull$PSDoc)
hcovidfull$PSDoc <- relevel(hcovidfull$PSDoc, "Anaesthetics")

hcovidfull$PSMinor <- as.factor(hcovidfull$PSMinor)
hcovidfull$PSMinor <- relevel(hcovidfull$PSMinor, "Medical")

hcovidfull$Facility <- as.factor(hcovidfull$Facility)
hcovidfull$Facility <- relevel(hcovidfull$Facility, "Hospital")

hcovidfull$ExposureComp <- as.factor(hcovidfull$ExposureComp)
hcovidfull$ExposureComp <- factor(hcovidfull$ExposureComp, level = c("None", "Clinical contact only", "AGP exposure only", "Clinical contact and AGP exposure"))

hcovidfull$AreaDef <- as.factor(hcovidfull$AreaDef)
hcovidfull$AreaDef <- factor(hcovidfull$AreaDef, level = c("None", "One", "Two", "Three or more")) 

hcovidfull$AGPDef <- as.factor(hcovidfull$AGPDef)
hcovidfull$AGPDef <- factor(hcovidfull$AGPDef, level = c("None", "One", "Two or more")) 

hcovidfull$NoPPEexpofreq[is.na(hcovidfull$NoPPEexpofreq)] <- "Never"
hcovidfull$NoPPEexpofreq <- as.factor(hcovidfull$NoPPEexpofreq)
hcovidfull$NoPPEexpofreq <- factor(hcovidfull$NoPPEexpofreq, level = c("Never", "Rarely", "Sometimes", "Often", "Always")) 

##data frame formation
hcovidsi <- hcovidfull %>% filter(CompSI == TRUE)
hcovidhosp <- hcovidfull %>% filter(CompHosp == TRUE)
hcovidpos <- hcovidfull %>% filter(CompPosi == TRUE)
hcovidcompout <- hcovidfull %>% filter(CompOut == TRUE)
hcovidtest <- hcovidfull %>% filter(TestOutcome !="Untested") #not required for composites


#"Feel" for the data
##age
ggplot(data = hcovidfull, aes(x = Age, y = as.numeric(CompOut))) + 
  geom_point() + 
  geom_smooth(method = "loess")

##comorbiditytotal
scatter.smooth(jitter(as.numeric(hcovidfull$CompOut)) ~ jitter(hcovidfull$ComorbidityTotal), family = "gaussian", lpars = list(col = "red"))

##agptotal
scatter.smooth(jitter(as.numeric(hcovidfull$CompOut)) ~ jitter(hcovidfull$AGPTotal), family = "gaussian", lpars = list(col = "red"))

##areatotal
scatter.smooth(jitter(as.numeric(hcovidfull$CompOut)) ~ jitter(hcovidfull$AreaTotal), family = "gaussian", lpars = list(col = "red"))

##ppelacktotal
scatter.smooth(jitter(as.numeric(hcovidfull$CompOut)) ~ jitter(hcovidfull$PPELackTotal), family = "gaussian", lpars = list(col = "red"))


#glm for individual BAME groups --> COMPOSITE
##BAME MODEL
hcovidfullglmbame <- glm(CompOut ~ Age + Sex + EthnicMain + hChildrenDef + Hypertension + Diabetes + Cancer + `Heart disease` + Immunosuppression + `Respiratory disease` + `Renal disease` + `Liver disease` + `Neurological disease` + `Obesity` + `Prefer not to say` + Smoker + Country + Facility + RoleGroup + PublicTransport + contactCOVID + AGPExpo + PPETraining + PPELack + NoPPEexpofreq + ReusePPE + CustomPPE, data = hcovidfull, family = binomial)

##jtools summary with OR for BAME MODEL 
summ(hcovidfullglmbame, exp = TRUE, digits = 3) #jtools summary with OR

##dataframe summary with OR for BAME MODEL
bamePvals <- as.data.frame(coef(summary(hcovidfullglmbame))[, 4])
hcovidbameaOR <- as.data.frame(round(exp(cbind(coef(hcovidfullglmbame), confint(hcovidfullglmbame))), digits = 2))
hcovidbameaOR <- hcovidbameaOR %>% 
  rownames_to_column("Variables") %>%
  rename(`adjusted OR` = V1) %>%
  mutate(`95%CI` = paste(hcovidbameaOR$`2.5 %`, hcovidbameaOR$`97.5 %`, sep = "-")) %>% 
  mutate("p-value" = round(bamePvals$`coef(summary(hcovidfullglmbame))[, 4]`, digits = 3)) %>% 
  subset(., select = -c(`2.5 %`, `97.5 %`)) %>% 
  mutate(sig = `p-value` < 0.05)

#view(hcovidbameaOR)
#view(filter(hcovidbameaOR, sig == TRUE))


#glm for "Smokers" re: collider bias --> COMPOSITE
##SMOKER MODEL
hcovidfullglmsmoker <- glm(CompOut ~ Age + Sex + EthnicBAME + hChildrenDef + Smoker + Country + Facility + RoleGroup + PublicTransport + contactCOVID + AGPExpo + PPETraining + PPELack + NoPPEexpofreq + ReusePPE + CustomPPE, data = hcovidfull, family = binomial)

##jtools summary with OR for SMOKER MODEL 
summ(hcovidfullglmsmoker, exp = TRUE, digits = 3)

##dataframe summary with OR for SMOKER MODEL
smokerPvals <- as.data.frame(coef(summary(hcovidfullglmsmoker))[, 4])
hcovidsmokeraOR <- as.data.frame(round(exp(cbind(coef(hcovidfullglmsmoker), confint(hcovidfullglmsmoker))), digits = 2))
hcovidsmokeraOR <- hcovidsmokeraOR %>% 
  rownames_to_column("Variables") %>%
  rename(`adjusted OR` = V1) %>%
  mutate(`95%CI` = paste(hcovidsmokeraOR$`2.5 %`, hcovidsmokeraOR$`97.5 %`, sep = "-")) %>% 
  mutate("p-value" = round(smokerPvals$`coef(summary(hcovidfullglmsmoker))[, 4]`, digits = 3)) %>% 
  subset(., select = -c(`2.5 %`, `97.5 %`)) %>% 
  mutate(sig = `p-value` < 0.05)

#view(hcovidsmokeraOR)
#view(filter(hcovidsmokeraOR, sig == TRUE))


#glm for Area --> COMPOSITE 
###[Note: AreaTotal contains 0 and thus, can't be utilsed in this subgroup]
hcovAREAglm <- glm(CompOut ~ Age + Sex + EthnicBAME + hChildrenDef + Hypertension + Diabetes + Cancer + `Heart disease` + Immunosuppression + `Respiratory disease` + `Renal disease` + `Liver disease` + `Neurological disease` + `Obesity` + `Prefer not to say` + Smoker + Country + Facility + RoleGroup + PublicTransport + COVID19zone + CareHome + InpClinic + OutClinic + DSU + ED + EndoscopyArea + GP + HomeVisits + ICU + InpWardnonCOVID + Maternity + OT + Radiology + OtherArea + AGPExpo + PPETraining + PPELack + NoPPEexpofreq + ReusePPE + CustomPPE, data = filter(hcovidfull, contactCOVID == "Yes"), family = binomial)

##summary for AREA MODEL 
summary(hcovAREAglm)

##dataframe summary with OR for AREA MODEL
Pvals <- as.data.frame(coef(summary(hcovAREAglm))[, 4])
hcovAREAaOR <- as.data.frame(round(exp(cbind(coef(hcovAREAglm), confint(hcovAREAglm))), digits = 2))
hcovAREAaOR <- hcovAREAaOR %>% 
  rownames_to_column("Variables") %>%
  rename(`adjusted OR` = V1) %>%
  mutate(`95%CI` = paste(hcovAREAaOR$`2.5 %`, hcovAREAaOR$`97.5 %`, sep = "-")) %>% 
  mutate("p-value" = round(Pvals$`coef(summary(hcovAREAglm))[, 4]`, digits = 3)) %>% 
  subset(., select = -c(`2.5 %`, `97.5 %`)) %>% 
  mutate(sig = `p-value` < 0.05)

#view(hcovAREAaOR)
#view(filter(hcovAREAaOR, sig == TRUE))


#glm for AGP --> COMPOSITE
###[Note: AGPTotal contains 0 and thus, can't be utilsed in this subgroup]
hcovAGPglm <- glm(CompOut ~ Age + Sex + EthnicBAME + hChildrenDef + Hypertension + Diabetes + Cancer + `Heart disease` + Immunosuppression + `Respiratory disease` + `Renal disease` + `Liver disease` + `Neurological disease` + `Obesity` + `Prefer not to say` + Smoker + Country + Facility + RoleGroup + PublicTransport + contactCOVID + `Bronchoscopy/ENT` + `Dental Procedures` + `CPR` + `HFNO` + `HFOV` + `Sputum` + `IntubationExtubation` + `Nebulisers` + `NIV` + `Surgery` + `Tracheostomy` + `EndoscopyAGP` + `OtherAGP` + PPETraining + PPELack + NoPPEexpofreq + ReusePPE + CustomPPE, data = filter(hcovidfull, AGPExpo == "Yes"), family = binomial)

##summary for AGP MODEL 
summary(hcovAGPglm)

##dataframe summary with OR for AGP MODEL
Pvals <- as.data.frame(coef(summary(hcovAGPglm))[, 4])
hcovAGPaOR <- as.data.frame(round(exp(cbind(coef(hcovAGPglm), confint(hcovAGPglm))), digits = 2))
hcovAGPaOR <- hcovAGPaOR %>% 
  rownames_to_column("Variables") %>%
  rename(`adjusted OR` = V1) %>%
  mutate(`95%CI` = paste(hcovAGPaOR$`2.5 %`, hcovAGPaOR$`97.5 %`, sep = "-")) %>% 
  mutate("p-value" = round(Pvals$`coef(summary(hcovAGPglm))[, 4]`, digits = 3)) %>% 
  subset(., select = -c(`2.5 %`, `97.5 %`)) %>% 
  mutate(sig = `p-value` < 0.05)

#view(hcovAGPaOR)
#view(filter(hcovAGPaOR, sig == TRUE))


#glm for restricted outcome (i.e. laboratory-confirmed SARS-CoV-2 only)
hcovidposiglm <- glm(CompPosi ~ Age + Sex + EthnicBAME + hChildrenDef + Hypertension + Diabetes + Cancer + `Heart disease` + Immunosuppression + `Respiratory disease` + `Renal disease` + `Liver disease` + `Neurological disease` + `Obesity` + `Prefer not to say` + Smoker + Country + Facility + RoleGroup + PublicTransport + contactCOVID + AGPExpo + PPETraining + PPELack + NoPPEexpofreq + ReusePPE + CustomPPE, data = hcovidfull, family = binomial)

##summary for COVID POSI MODEL 
summary(hcovidposiglm)

##dataframe summary with OR for COVID POSI
Pvals <- as.data.frame(coef(summary(hcovidposiglm))[, 4])
hcovidposiglm <- as.data.frame(round(exp(cbind(coef(hcovidposiglm), confint(hcovidposiglm))), digits = 2))
hcovidposiglm <- hcovidposiglm %>% 
  rownames_to_column("Variables") %>%
  rename(`adjusted OR` = V1) %>%
  mutate(`95%CI` = paste(hcovidposiaOR$`2.5 %`, hcovidposiaOR$`97.5 %`, sep = "-")) %>% 
  mutate("p-value" = round(Pvals$`coef(summary(hcovidposiglm))[, 4]`, digits = 3)) %>% 
  subset(., select = -c(`2.5 %`, `97.5 %`)) %>% 
  mutate(sig = `p-value` < 0.05)

#view(hcovidposiaOR)
#view(filter(hcovidposiaOR, sig == TRUE))


#gt for TABLE: "BAME MODEL"
##initialise
bametrial <- data.frame(groups = c(
  "Age",
  rep("Sex", times = 2),
  rep("Ethnicity", times = 6),
  rep("Household - Persons", times = 3),
  rep("Comorbidities", times = 11),
  rep("Smoking status", times = 4),
  rep("Country", times = 4),
  rep("Main Healthcare Facility", times = 4),
  rep("Role Group", times = 5),
  rep("Public Transport to travel to work", times = 2),
  rep("Regular clinical contact with COVID-19 patients", times =2),
  rep("Regular exposure to AGP(s) performed in COVID-19 patients", times = 2),
  rep("Sufficient training in PPE usage", times = 2),
  rep("Lacked access to PPE items for clinical contact", times = 2),
  rep("Clinical contact without adequate PPE", times = 5),
  rep("Reused disposable PPE", times = 2),
  rep("Used improvised PPE", times = 2)),
  
  "rownames" = c("Age", "Female", "Male", "White", "Another ethnic group", "Asian or Asian British", "Black, African, Black British or Caribbean", "Mixed or multiple ethnic groups", "Prefer not to say", "Lives alone", "Lives with 1 or more persons; no children", "Lives with 1 or more persons; has children", "Hypertension", "Diabetes", "Cancer", "Heart disease", "Immunosuppression", "Respiratory disease", "Renal disease", "Liver disease", "Neurological disease", "Obesity", "Prefer not to say", "Never smoked", "Current or Ex-smoker within 1 year", "Ex-smoker > 1 year", "Prefer not to say", "England", "Northern Ireland", "Scotland", "Wales", "Hospital", "Community healthcare facility", "Other", "Social care facility", "Nurses, midwives and associated staff", "Allied health professionals", "Dentists and dental staff", "Doctors", "Other", "No", "Yes", "No", "Yes", "No", "Yes", "No", "Yes", "No", "Yes", "Never", "Rarely", "Sometimes", "Often", "Always", "No", "Yes", "No", "Yes"),
  
  "multivariate.OR" = c(hcovidbameaOR$`adjusted OR`[2], NA, hcovidbameaOR$`adjusted OR`[3], NA, hcovidbameaOR$`adjusted OR`[4], hcovidbameaOR$`adjusted OR`[5], hcovidbameaOR$`adjusted OR`[6], hcovidbameaOR$`adjusted OR`[7], hcovidbameaOR$`adjusted OR`[8], NA, hcovidbameaOR$`adjusted OR`[9], hcovidbameaOR$`adjusted OR`[10], hcovidbameaOR$`adjusted OR`[11], hcovidbameaOR$`adjusted OR`[12], hcovidbameaOR$`adjusted OR`[13], hcovidbameaOR$`adjusted OR`[14], hcovidbameaOR$`adjusted OR`[15], hcovidbameaOR$`adjusted OR`[16], hcovidbameaOR$`adjusted OR`[17], hcovidbameaOR$`adjusted OR`[18], hcovidbameaOR$`adjusted OR`[19], hcovidbameaOR$`adjusted OR`[20], hcovidbameaOR$`adjusted OR`[21], NA, hcovidbameaOR$`adjusted OR`[22], hcovidbameaOR$`adjusted OR`[23], hcovidbameaOR$`adjusted OR`[24], NA, hcovidbameaOR$`adjusted OR`[25], hcovidbameaOR$`adjusted OR`[26], hcovidbameaOR$`adjusted OR`[27], NA, hcovidbameaOR$`adjusted OR`[28], hcovidbameaOR$`adjusted OR`[29], hcovidbameaOR$`adjusted OR`[30], NA, hcovidbameaOR$`adjusted OR`[31], hcovidbameaOR$`adjusted OR`[32], hcovidbameaOR$`adjusted OR`[33], hcovidbameaOR$`adjusted OR`[34], NA, hcovidbameaOR$`adjusted OR`[35], NA, hcovidbameaOR$`adjusted OR`[36], NA, hcovidbameaOR$`adjusted OR`[37], NA, hcovidbameaOR$`adjusted OR`[38], NA, hcovidbameaOR$`adjusted OR`[39], NA, hcovidbameaOR$`adjusted OR`[40], hcovidbameaOR$`adjusted OR`[41], hcovidbameaOR$`adjusted OR`[42], hcovidbameaOR$`adjusted OR`[43], NA, hcovidbameaOR$`adjusted OR`[44], NA, hcovidbameaOR$`adjusted OR`[45]),
  
  "95CI" = c(hcovidbameaOR$`95%CI`[2], NA, hcovidbameaOR$`95%CI`[3], NA, hcovidbameaOR$`95%CI`[4], hcovidbameaOR$`95%CI`[5], hcovidbameaOR$`95%CI`[6], hcovidbameaOR$`95%CI`[7], hcovidbameaOR$`95%CI`[8], NA, hcovidbameaOR$`95%CI`[9], hcovidbameaOR$`95%CI`[10], hcovidbameaOR$`95%CI`[11], hcovidbameaOR$`95%CI`[12], hcovidbameaOR$`95%CI`[13], hcovidbameaOR$`95%CI`[14], hcovidbameaOR$`95%CI`[15], hcovidbameaOR$`95%CI`[16], hcovidbameaOR$`95%CI`[17], hcovidbameaOR$`95%CI`[18], hcovidbameaOR$`95%CI`[19], hcovidbameaOR$`95%CI`[20], hcovidbameaOR$`95%CI`[21], NA, hcovidbameaOR$`95%CI`[22], hcovidbameaOR$`95%CI`[23], hcovidbameaOR$`95%CI`[24], NA, hcovidbameaOR$`95%CI`[25], hcovidbameaOR$`95%CI`[26], hcovidbameaOR$`95%CI`[27], NA, hcovidbameaOR$`95%CI`[28], hcovidbameaOR$`95%CI`[29], hcovidbameaOR$`95%CI`[30], NA, hcovidbameaOR$`95%CI`[31], hcovidbameaOR$`95%CI`[32], hcovidbameaOR$`95%CI`[33], hcovidbameaOR$`95%CI`[34], NA, hcovidbameaOR$`95%CI`[35], NA, hcovidbameaOR$`95%CI`[36], NA, hcovidbameaOR$`95%CI`[37], NA, hcovidbameaOR$`95%CI`[38], NA, hcovidbameaOR$`95%CI`[39], NA, hcovidbameaOR$`95%CI`[40], hcovidbameaOR$`95%CI`[41], hcovidbameaOR$`95%CI`[42], hcovidbameaOR$`95%CI`[43], NA, hcovidbameaOR$`95%CI`[44], NA, hcovidbameaOR$`95%CI`[45]),
  
  "adjpvalue" = c(hcovidbameaOR$`p-value`[2], NA, hcovidbameaOR$`p-value`[3], NA, hcovidbameaOR$`p-value`[4], hcovidbameaOR$`p-value`[5], hcovidbameaOR$`p-value`[6], hcovidbameaOR$`p-value`[7], hcovidbameaOR$`p-value`[8], NA, hcovidbameaOR$`p-value`[9], hcovidbameaOR$`p-value`[10], hcovidbameaOR$`p-value`[11], hcovidbameaOR$`p-value`[12], hcovidbameaOR$`p-value`[13], hcovidbameaOR$`p-value`[14], hcovidbameaOR$`p-value`[15], hcovidbameaOR$`p-value`[16], hcovidbameaOR$`p-value`[17], hcovidbameaOR$`p-value`[18], hcovidbameaOR$`p-value`[19], hcovidbameaOR$`p-value`[20], hcovidbameaOR$`p-value`[21], NA, hcovidbameaOR$`p-value`[22], hcovidbameaOR$`p-value`[23], hcovidbameaOR$`p-value`[24], NA, hcovidbameaOR$`p-value`[25], hcovidbameaOR$`p-value`[26], hcovidbameaOR$`p-value`[27], NA, hcovidbameaOR$`p-value`[28], hcovidbameaOR$`p-value`[29], hcovidbameaOR$`p-value`[30], NA, hcovidbameaOR$`p-value`[31], hcovidbameaOR$`p-value`[32], hcovidbameaOR$`p-value`[33], hcovidbameaOR$`p-value`[34], NA, hcovidbameaOR$`p-value`[35], NA, hcovidbameaOR$`p-value`[36], NA, hcovidbameaOR$`p-value`[37], NA, hcovidbameaOR$`p-value`[38], NA, hcovidbameaOR$`p-value`[39], NA, hcovidbameaOR$`p-value`[40], hcovidbameaOR$`p-value`[41], hcovidbameaOR$`p-value`[42], hcovidbameaOR$`p-value`[43], NA, hcovidbameaOR$`p-value`[44], NA, hcovidbameaOR$`p-value`[45]))

bametrial$adjpvalue[bametrial$adjpvalue<0.001] <- "<0.001"
bametrial[is.na(bametrial)] <- "Ref"

##create gt table for BAME MODEL
gthcovidbameOR <- bametrial %>% 
  gt(groupname_col = "groups") %>%
  tab_header(
    title = "eTable 6. Multivariable logistic regression model featuring constituent BAME groups",
    subtitle = "") %>%
  tab_stubhead(label = "") %>% 
  cols_label(
    rownames = "",
    multivariate.OR = "Multivariable adjusted OR",
    X95CI = "95%CI",
    adjpvalue = md("*p*-value")) %>% 
  cols_align(align = "center", columns = vars(multivariate.OR, X95CI, adjpvalue)) %>% 
  tab_footnote(
    footnote = "Adjusted for all the above listed variables using multivariable logistic regression",
    locations = cells_column_labels(columns = vars(multivariate.OR))) %>% 
  tab_source_note(source_note = md("Univariate and multivariate odds ratio (OR), 95% confidence intervals (95%CI)  
                                   Ref = Reference value")) %>% 
  tab_options(heading.align = "left") %>% 
  tab_style(
    style = cell_text(style = "italic", indent = pct(2.5)),
    locations = cells_body(columns = vars(rownames))
  )


#gt for TABLE: "SMOKER MODEL"
##initialise
smokertrial <- data.frame(groups = c(
  "Age",
  rep("Sex", times = 2),
  rep("Ethnicity", times = 3),
  rep("Household - Persons", times = 3),
  rep("Smoking status", times = 4),
  rep("Country", times = 4),
  rep("Main Healthcare Facility", times = 4),
  rep("Role Group", times = 5),
  rep("Public Transport to travel to work", times = 2),
  rep("Regular clinical contact with COVID-19 patients", times =2),
  rep("Regular exposure to AGP(s) performed in COVID-19 patients", times = 2),
  rep("Sufficient training in PPE usage", times = 2),
  rep("Lacked access to PPE items for clinical contact", times = 2),
  rep("Clinical contact without adequate PPE", times = 5),
  rep("Reused disposable PPE", times = 2),
  rep("Used improvised PPE", times = 2)),
  
  "rownames" = c("Age", "Female", "Male", "White", "BAME", "Prefer not to say", "Lives alone", "Lives with 1 or more persons; no children", "Lives with 1 or more persons; has children", "Never smoked", "Current or Ex-smoker within 1 year", "Ex-smoker > 1 year", "Prefer not to say", "England", "Northern Ireland", "Scotland", "Wales", "Hospital", "Community healthcare facility", "Other", "Social care facility", "Nurses, midwives and associated staff", "Allied health professionals", "Dentists and dental staff", "Doctors", "Other", "No", "Yes", "No", "Yes", "No", "Yes", "No", "Yes", "No", "Yes", "Never", "Rarely", "Sometimes", "Often", "Always", "No", "Yes", "No", "Yes"),

  "multivariate.OR" = c(hcovidsmokeraOR$`adjusted OR`[2], NA, hcovidsmokeraOR$`adjusted OR`[3], NA, hcovidsmokeraOR$`adjusted OR`[4], hcovidsmokeraOR$`adjusted OR`[5], NA, hcovidsmokeraOR$`adjusted OR`[6], hcovidsmokeraOR$`adjusted OR`[7], NA, hcovidsmokeraOR$`adjusted OR`[8], hcovidsmokeraOR$`adjusted OR`[9], hcovidsmokeraOR$`adjusted OR`[10], NA, hcovidsmokeraOR$`adjusted OR`[11], hcovidsmokeraOR$`adjusted OR`[12], hcovidsmokeraOR$`adjusted OR`[13], NA, hcovidsmokeraOR$`adjusted OR`[14], hcovidsmokeraOR$`adjusted OR`[15], hcovidsmokeraOR$`adjusted OR`[16], NA, hcovidsmokeraOR$`adjusted OR`[17], hcovidsmokeraOR$`adjusted OR`[18], hcovidsmokeraOR$`adjusted OR`[19], hcovidsmokeraOR$`adjusted OR`[20], NA, hcovidsmokeraOR$`adjusted OR`[21], NA, hcovidsmokeraOR$`adjusted OR`[22], NA, hcovidsmokeraOR$`adjusted OR`[23], NA, hcovidsmokeraOR$`adjusted OR`[24], NA, hcovidsmokeraOR$`adjusted OR`[25], NA, hcovidsmokeraOR$`adjusted OR`[26], hcovidsmokeraOR$`adjusted OR`[27], hcovidsmokeraOR$`adjusted OR`[28], hcovidsmokeraOR$`adjusted OR`[29], NA, hcovidsmokeraOR$`adjusted OR`[30], NA, hcovidsmokeraOR$`adjusted OR`[31]),
  
  "95CI" = c(hcovidsmokeraOR$`95%CI`[2], NA, hcovidsmokeraOR$`95%CI`[3], NA, hcovidsmokeraOR$`95%CI`[4], hcovidsmokeraOR$`95%CI`[5], NA, hcovidsmokeraOR$`95%CI`[6], hcovidsmokeraOR$`95%CI`[7], NA, hcovidsmokeraOR$`95%CI`[8], hcovidsmokeraOR$`95%CI`[9], hcovidsmokeraOR$`95%CI`[10], NA, hcovidsmokeraOR$`95%CI`[11], hcovidsmokeraOR$`95%CI`[12], hcovidsmokeraOR$`95%CI`[13], NA, hcovidsmokeraOR$`95%CI`[14], hcovidsmokeraOR$`95%CI`[15], hcovidsmokeraOR$`95%CI`[16], NA, hcovidsmokeraOR$`95%CI`[17], hcovidsmokeraOR$`95%CI`[18], hcovidsmokeraOR$`95%CI`[19], hcovidsmokeraOR$`95%CI`[20], NA, hcovidsmokeraOR$`95%CI`[21], NA, hcovidsmokeraOR$`95%CI`[22], NA, hcovidsmokeraOR$`95%CI`[23], NA, hcovidsmokeraOR$`95%CI`[24], NA, hcovidsmokeraOR$`95%CI`[25], NA, hcovidsmokeraOR$`95%CI`[26], hcovidsmokeraOR$`95%CI`[27], hcovidsmokeraOR$`95%CI`[28], hcovidsmokeraOR$`95%CI`[29], NA, hcovidsmokeraOR$`95%CI`[30], NA, hcovidsmokeraOR$`95%CI`[31]),
  
  "adjpvalue" = c(hcovidsmokeraOR$`p-value`[2], NA, hcovidsmokeraOR$`p-value`[3], NA, hcovidsmokeraOR$`p-value`[4], hcovidsmokeraOR$`p-value`[5], NA, hcovidsmokeraOR$`p-value`[6], hcovidsmokeraOR$`p-value`[7], NA, hcovidsmokeraOR$`p-value`[8], hcovidsmokeraOR$`p-value`[9], hcovidsmokeraOR$`p-value`[10], NA, hcovidsmokeraOR$`p-value`[11], hcovidsmokeraOR$`p-value`[12], hcovidsmokeraOR$`p-value`[13], NA, hcovidsmokeraOR$`p-value`[14], hcovidsmokeraOR$`p-value`[15], hcovidsmokeraOR$`p-value`[16], NA, hcovidsmokeraOR$`p-value`[17], hcovidsmokeraOR$`p-value`[18], hcovidsmokeraOR$`p-value`[19], hcovidsmokeraOR$`p-value`[20], NA, hcovidsmokeraOR$`p-value`[21], NA, hcovidsmokeraOR$`p-value`[22], NA, hcovidsmokeraOR$`p-value`[23], NA, hcovidsmokeraOR$`p-value`[24], NA, hcovidsmokeraOR$`p-value`[25], NA, hcovidsmokeraOR$`p-value`[26], hcovidsmokeraOR$`p-value`[27], hcovidsmokeraOR$`p-value`[28], hcovidsmokeraOR$`p-value`[29], NA, hcovidsmokeraOR$`p-value`[30], NA, hcovidsmokeraOR$`p-value`[31]))

smokertrial$adjpvalue[smokertrial$adjpvalue<0.001] <- "<0.001"
smokertrial[is.na(smokertrial)] <- "Ref"

##create gt table for SMOKER MODEL
gthcovidsmokerOR <- smokertrial %>% 
  gt(groupname_col = "groups") %>%
  tab_header(
    title = "eTable 7. Multivariable logistic regression model with comorbidities removed to assess for collider bias with respect to smoking status",
    subtitle = "") %>%
  tab_stubhead(label = "") %>% 
  cols_label(
    rownames = "",
    multivariate.OR = "Multivariable adjusted OR",
    X95CI = "95%CI",
    adjpvalue = md("*p*-value")) %>% 
  cols_align(align = "center", columns = vars(multivariate.OR, X95CI, adjpvalue)) %>% 
  tab_footnote(
    footnote = "Adjusted for all the above listed variables using multivariable logistic regression",
    locations = cells_column_labels(columns = vars(multivariate.OR))) %>% 
  tab_source_note(source_note = md("Multivariate odds ratio (OR), 95% confidence intervals (95%CI)  
                                   Ref = Reference value")) %>% 
  tab_options(heading.align = "left") %>% 
  tab_style(
    style = cell_text(style = "italic", indent = pct(2.5)),
    locations = cells_body(columns = vars(rownames))
  )


#gt for TABLE: "AREA MODEL"
##initialise
areatrial <- data.frame(groups = c(
  "Age",
  rep("Sex", times = 2),
  rep("Ethnicity", times = 3),
  rep("Household - Persons", times = 3),
  rep("Comorbidities", times = 11),
  rep("Smoking status", times = 4),
  rep("Country", times = 4),
  rep("Main Healthcare Facility", times = 4),
  rep("Role Group", times = 5),
  rep("Public Transport to travel to work", times = 2),
  rep("Area of regular clinical contact with COVID-19 patients", times = 15),
  rep("Regular exposure to AGP(s) performed in COVID-19 patients", times = 2),
  rep("Sufficient training in PPE usage", times = 2),
  rep("Lacked access to PPE items for clinical contact", times = 2),
  rep("Clinical contact without adequate PPE", times = 5),
  rep("Reused disposable PPE", times = 2),
  rep("Used improvised PPE", times = 2)),

  "rownames" = c("Age", "Female", "Male", "White", "BAME", "Prefer not to say", "Lives alone", "Lives with 1 or more persons; no children", "Lives with 1 or more persons; has children", "Hypertension", "Diabetes", "Cancer", "Heart disease", "Immunosuppression", "Respiratory disease", "Renal disease", "Liver disease", "Neurological disease", "Obesity", "Prefer not to say", "Never smoked", "Current or Ex-smoker within 1 year", "Ex-smoker > 1 year", "Prefer not to say", "England", "Northern Ireland", "Scotland", "Wales", "Hospital", "Community healthcare facility", "Other", "Social care facility", "Nurses, midwives and associated staff", "Allied health professionals", "Dentists and dental staff", "Doctors", "Other", "No", "Yes", "COVID-19 zone", "Care/Nursing home", "Inpatient clinic", "Outpatient clinic", "DSU", "ED", "Endoscopy", "GP practice", "Home visits", "ICU/HDU", "Inpatient ward (non-COVID)", "Maternity", "Operating theatre", "Radiology", "Other", "No", "Yes", "No", "Yes", "No", "Yes", "Never", "Rarely", "Sometimes", "Often", "Always", "No", "Yes", "No", "Yes"),
  
  "multivariate.OR" = c(hcovAREAaOR$`adjusted OR`[2], NA, hcovAREAaOR$`adjusted OR`[3], NA, hcovAREAaOR$`adjusted OR`[4], hcovAREAaOR$`adjusted OR`[5], NA, hcovAREAaOR$`adjusted OR`[6], hcovAREAaOR$`adjusted OR`[7], hcovAREAaOR$`adjusted OR`[8], hcovAREAaOR$`adjusted OR`[9], hcovAREAaOR$`adjusted OR`[10], hcovAREAaOR$`adjusted OR`[11], hcovAREAaOR$`adjusted OR`[12], hcovAREAaOR$`adjusted OR`[13], hcovAREAaOR$`adjusted OR`[14], hcovAREAaOR$`adjusted OR`[15], hcovAREAaOR$`adjusted OR`[16], hcovAREAaOR$`adjusted OR`[17], hcovAREAaOR$`adjusted OR`[18], NA, hcovAREAaOR$`adjusted OR`[19], hcovAREAaOR$`adjusted OR`[20], hcovAREAaOR$`adjusted OR`[21], NA, hcovAREAaOR$`adjusted OR`[22], hcovAREAaOR$`adjusted OR`[23], hcovAREAaOR$`adjusted OR`[24], NA, hcovAREAaOR$`adjusted OR`[25], hcovAREAaOR$`adjusted OR`[26], hcovAREAaOR$`adjusted OR`[27], NA, hcovAREAaOR$`adjusted OR`[28], hcovAREAaOR$`adjusted OR`[29], hcovAREAaOR$`adjusted OR`[30], hcovAREAaOR$`adjusted OR`[31], NA, hcovAREAaOR$`adjusted OR`[32], hcovAREAaOR$`adjusted OR`[33], hcovAREAaOR$`adjusted OR`[34], hcovAREAaOR$`adjusted OR`[35], hcovAREAaOR$`adjusted OR`[36], hcovAREAaOR$`adjusted OR`[37], hcovAREAaOR$`adjusted OR`[38], hcovAREAaOR$`adjusted OR`[39], hcovAREAaOR$`adjusted OR`[40], hcovAREAaOR$`adjusted OR`[41], hcovAREAaOR$`adjusted OR`[42], hcovAREAaOR$`adjusted OR`[43], hcovAREAaOR$`adjusted OR`[44], hcovAREAaOR$`adjusted OR`[45], hcovAREAaOR$`adjusted OR`[46], hcovAREAaOR$`adjusted OR`[47], NA, hcovAREAaOR$`adjusted OR`[48], NA, hcovAREAaOR$`adjusted OR`[49], NA, hcovAREAaOR$`adjusted OR`[50], NA, hcovAREAaOR$`adjusted OR`[51], hcovAREAaOR$`adjusted OR`[52], hcovAREAaOR$`adjusted OR`[53], hcovAREAaOR$`adjusted OR`[54], NA, hcovAREAaOR$`adjusted OR`[55], NA, hcovAREAaOR$`adjusted OR`[56]),
  
  "95CI" = c(hcovAREAaOR$`95%CI`[2], NA, hcovAREAaOR$`95%CI`[3], NA, hcovAREAaOR$`95%CI`[4], hcovAREAaOR$`95%CI`[5], NA, hcovAREAaOR$`95%CI`[6], hcovAREAaOR$`95%CI`[7], hcovAREAaOR$`95%CI`[8], hcovAREAaOR$`95%CI`[9], hcovAREAaOR$`95%CI`[10], hcovAREAaOR$`95%CI`[11], hcovAREAaOR$`95%CI`[12], hcovAREAaOR$`95%CI`[13], hcovAREAaOR$`95%CI`[14], hcovAREAaOR$`95%CI`[15], hcovAREAaOR$`95%CI`[16], hcovAREAaOR$`95%CI`[17], hcovAREAaOR$`95%CI`[18], NA, hcovAREAaOR$`95%CI`[19], hcovAREAaOR$`95%CI`[20], hcovAREAaOR$`95%CI`[21], NA, hcovAREAaOR$`95%CI`[22], hcovAREAaOR$`95%CI`[23], hcovAREAaOR$`95%CI`[24], NA, hcovAREAaOR$`95%CI`[25], hcovAREAaOR$`95%CI`[26], hcovAREAaOR$`95%CI`[27], NA, hcovAREAaOR$`95%CI`[28], hcovAREAaOR$`95%CI`[29], hcovAREAaOR$`95%CI`[30], hcovAREAaOR$`95%CI`[31], NA, hcovAREAaOR$`95%CI`[32], hcovAREAaOR$`95%CI`[33], hcovAREAaOR$`95%CI`[34], hcovAREAaOR$`95%CI`[35], hcovAREAaOR$`95%CI`[36], hcovAREAaOR$`95%CI`[37], hcovAREAaOR$`95%CI`[38], hcovAREAaOR$`95%CI`[39], hcovAREAaOR$`95%CI`[40], hcovAREAaOR$`95%CI`[41], hcovAREAaOR$`95%CI`[42], hcovAREAaOR$`95%CI`[43], hcovAREAaOR$`95%CI`[44], hcovAREAaOR$`95%CI`[45], hcovAREAaOR$`95%CI`[46], hcovAREAaOR$`95%CI`[47], NA, hcovAREAaOR$`95%CI`[48], NA, hcovAREAaOR$`95%CI`[49], NA, hcovAREAaOR$`95%CI`[50], NA, hcovAREAaOR$`95%CI`[51], hcovAREAaOR$`95%CI`[52], hcovAREAaOR$`95%CI`[53], hcovAREAaOR$`95%CI`[54], NA, hcovAREAaOR$`95%CI`[55], NA, hcovAREAaOR$`95%CI`[56]),

  "adjpvalue" = c(hcovAREAaOR$`p-value`[2], NA, hcovAREAaOR$`p-value`[3], NA, hcovAREAaOR$`p-value`[4], hcovAREAaOR$`p-value`[5], NA, hcovAREAaOR$`p-value`[6], hcovAREAaOR$`p-value`[7], hcovAREAaOR$`p-value`[8], hcovAREAaOR$`p-value`[9], hcovAREAaOR$`p-value`[10], hcovAREAaOR$`p-value`[11], hcovAREAaOR$`p-value`[12], hcovAREAaOR$`p-value`[13], hcovAREAaOR$`p-value`[14], hcovAREAaOR$`p-value`[15], hcovAREAaOR$`p-value`[16], hcovAREAaOR$`p-value`[17], hcovAREAaOR$`p-value`[18], NA, hcovAREAaOR$`p-value`[19], hcovAREAaOR$`p-value`[20], hcovAREAaOR$`p-value`[21], NA, hcovAREAaOR$`p-value`[22], hcovAREAaOR$`p-value`[23], hcovAREAaOR$`p-value`[24], NA, hcovAREAaOR$`p-value`[25], hcovAREAaOR$`p-value`[26], hcovAREAaOR$`p-value`[27], NA, hcovAREAaOR$`p-value`[28], hcovAREAaOR$`p-value`[29], hcovAREAaOR$`p-value`[30], hcovAREAaOR$`p-value`[31], NA, hcovAREAaOR$`p-value`[32], hcovAREAaOR$`p-value`[33], hcovAREAaOR$`p-value`[34], hcovAREAaOR$`p-value`[35], hcovAREAaOR$`p-value`[36], hcovAREAaOR$`p-value`[37], hcovAREAaOR$`p-value`[38], hcovAREAaOR$`p-value`[39], hcovAREAaOR$`p-value`[40], hcovAREAaOR$`p-value`[41], hcovAREAaOR$`p-value`[42], hcovAREAaOR$`p-value`[43], hcovAREAaOR$`p-value`[44], hcovAREAaOR$`p-value`[45], hcovAREAaOR$`p-value`[46], hcovAREAaOR$`p-value`[47], NA, hcovAREAaOR$`p-value`[48], NA, hcovAREAaOR$`p-value`[49], NA, hcovAREAaOR$`p-value`[50], NA, hcovAREAaOR$`p-value`[51], hcovAREAaOR$`p-value`[52], hcovAREAaOR$`p-value`[53], hcovAREAaOR$`p-value`[54], NA, hcovAREAaOR$`p-value`[55], NA, hcovAREAaOR$`p-value`[56]))

areatrial$adjpvalue[areatrial$adjpvalue<0.001] <- "<0.001"
areatrial[is.na(areatrial)] <- "Ref"

##create gt table for AREA MODEL
gthcovidareaOR <- areatrial %>% 
  gt(groupname_col = "groups") %>%
  tab_header(
    title = "eTable 8. Multivariable logistic regression model including clinical areas in which healthcare workers had regular clinical contact with suspected or confirmed COVID-19 patients",
    subtitle = "") %>%
  tab_stubhead(label = "") %>% 
  cols_label(
    rownames = "",
    multivariate.OR = "Multivariable adjusted OR",
    X95CI = "95%CI",
    adjpvalue = md("*p*-value")) %>% 
  cols_align(align = "center", columns = vars(multivariate.OR, X95CI, adjpvalue)) %>% 
  tab_footnote(
    footnote = "Adjusted for all the above listed variables using multivariable logistic regression",
    locations = cells_column_labels(columns = vars(multivariate.OR))) %>% 
  tab_source_note(source_note = md("Multivariate odds ratio (OR), 95% confidence intervals (95%CI)  
                                   Ref = Reference value")) %>% 
  tab_options(heading.align = "left") %>% 
  tab_style(
    style = cell_text(style = "italic", indent = pct(2.5)),
    locations = cells_body(columns = vars(rownames))
  )


#gt for TABLE: "AGP MODEL"
##initialise
agptrial <- data.frame(groups = c(
  "Age",
  rep("Sex", times = 2),
  rep("Ethnicity", times = 3),
  rep("Household - Persons", times = 3),
  rep("Comorbidities", times = 11),
  rep("Smoking status", times = 4),
  rep("Country", times = 4),
  rep("Main Healthcare Facility", times = 4),
  rep("Role Group", times = 5),
  rep("Public Transport to travel to work", times = 2),
  rep("Regular clinical contact with COVID-19 patients", times = 2),
  rep("Exposure to AGP performed in COVID-19 patients", times = 13),
  rep("Sufficient training in PPE usage", times = 2),
  rep("Lacked access to PPE items for clinical contact", times = 2),
  rep("Clinical contact without adequate PPE", times = 5),
  rep("Reused disposable PPE", times = 2),
  rep("Used improvised PPE", times = 2)),
  
  "rownames" = c("Age", "Female", "Male", "White", "BAME", "Prefer not to say", "Lives alone", "Lives with 1 or more persons; no children", "Lives with 1 or more persons; has children", "Hypertension", "Diabetes", "Cancer", "Heart disease", "Immunosuppression", "Respiratory disease", "Renal disease", "Liver disease", "Neurological disease", "Obesity", "Prefer not to say", "Never smoked", "Current or Ex-smoker within 1 year", "Ex-smoker > 1 year", "Prefer not to say", "England", "Northern Ireland", "Scotland", "Wales", "Hospital", "Community healthcare facility", "Other", "Social care facility", "Nurses, midwives and associated staff", "Allied health professionals", "Dentists and dental staff", "Doctors", "Other", "No", "Yes", "No", "Yes", "Bronchoscopy and ENT procedures", "Dental procedures", "Cardiopulmonary resuscitation", "High-flow nasal oxygen", "High frequency oscillatory ventilation", "Induction of sputum", "Intubation/Extubation", "Nebulisers", "Non-invasive ventilation", "Surgery and post-mortem", "Tracheostomy", "Endoscopy", "Other", "No", "Yes", "No", "Yes", "Never", "Rarely", "Sometimes", "Often", "Always", "No", "Yes", "No", "Yes"),

  "multivariate.OR" = c(hcovAGPaOR$`adjusted OR`[2], NA, hcovAGPaOR$`adjusted OR`[3], NA, hcovAGPaOR$`adjusted OR`[4], hcovAGPaOR$`adjusted OR`[5], NA, hcovAGPaOR$`adjusted OR`[6], hcovAGPaOR$`adjusted OR`[7], hcovAGPaOR$`adjusted OR`[8], hcovAGPaOR$`adjusted OR`[9], hcovAGPaOR$`adjusted OR`[10], hcovAGPaOR$`adjusted OR`[11], hcovAGPaOR$`adjusted OR`[12], hcovAGPaOR$`adjusted OR`[13], hcovAGPaOR$`adjusted OR`[14], hcovAGPaOR$`adjusted OR`[15], hcovAGPaOR$`adjusted OR`[16], hcovAGPaOR$`adjusted OR`[17], hcovAGPaOR$`adjusted OR`[18], NA, hcovAGPaOR$`adjusted OR`[19], hcovAGPaOR$`adjusted OR`[20], hcovAGPaOR$`adjusted OR`[21], NA, hcovAGPaOR$`adjusted OR`[22], hcovAGPaOR$`adjusted OR`[23], hcovAGPaOR$`adjusted OR`[24], NA, hcovAGPaOR$`adjusted OR`[25], hcovAGPaOR$`adjusted OR`[26], hcovAGPaOR$`adjusted OR`[27], NA, hcovAGPaOR$`adjusted OR`[28], hcovAGPaOR$`adjusted OR`[29], hcovAGPaOR$`adjusted OR`[30], hcovAGPaOR$`adjusted OR`[31], NA, hcovAGPaOR$`adjusted OR`[32], NA, hcovAGPaOR$`adjusted OR`[33], hcovAGPaOR$`adjusted OR`[34], hcovAGPaOR$`adjusted OR`[35], hcovAGPaOR$`adjusted OR`[36], hcovAGPaOR$`adjusted OR`[37], hcovAGPaOR$`adjusted OR`[38], hcovAGPaOR$`adjusted OR`[39], hcovAGPaOR$`adjusted OR`[40], hcovAGPaOR$`adjusted OR`[41], hcovAGPaOR$`adjusted OR`[42], hcovAGPaOR$`adjusted OR`[43], hcovAGPaOR$`adjusted OR`[44], hcovAGPaOR$`adjusted OR`[45], hcovAGPaOR$`adjusted OR`[46], NA, hcovAGPaOR$`adjusted OR`[47], NA, hcovAGPaOR$`adjusted OR`[48], NA, hcovAGPaOR$`adjusted OR`[49], hcovAGPaOR$`adjusted OR`[50], hcovAGPaOR$`adjusted OR`[51], hcovAGPaOR$`adjusted OR`[52], NA, hcovAGPaOR$`adjusted OR`[53], NA, hcovAGPaOR$`adjusted OR`[54]),
  
  "95CI" = c(hcovAGPaOR$`95%CI`[2], NA, hcovAGPaOR$`95%CI`[3], NA, hcovAGPaOR$`95%CI`[4], hcovAGPaOR$`95%CI`[5], NA, hcovAGPaOR$`95%CI`[6], hcovAGPaOR$`95%CI`[7], hcovAGPaOR$`95%CI`[8], hcovAGPaOR$`95%CI`[9], hcovAGPaOR$`95%CI`[10], hcovAGPaOR$`95%CI`[11], hcovAGPaOR$`95%CI`[12], hcovAGPaOR$`95%CI`[13], hcovAGPaOR$`95%CI`[14], hcovAGPaOR$`95%CI`[15], hcovAGPaOR$`95%CI`[16], hcovAGPaOR$`95%CI`[17], hcovAGPaOR$`95%CI`[18], NA, hcovAGPaOR$`95%CI`[19], hcovAGPaOR$`95%CI`[20], hcovAGPaOR$`95%CI`[21], NA, hcovAGPaOR$`95%CI`[22], hcovAGPaOR$`95%CI`[23], hcovAGPaOR$`95%CI`[24], NA, hcovAGPaOR$`95%CI`[25], hcovAGPaOR$`95%CI`[26], hcovAGPaOR$`95%CI`[27], NA, hcovAGPaOR$`95%CI`[28], hcovAGPaOR$`95%CI`[29], hcovAGPaOR$`95%CI`[30], hcovAGPaOR$`95%CI`[31], NA, hcovAGPaOR$`95%CI`[32], NA, hcovAGPaOR$`95%CI`[33], hcovAGPaOR$`95%CI`[34], hcovAGPaOR$`95%CI`[35], hcovAGPaOR$`95%CI`[36], hcovAGPaOR$`95%CI`[37], hcovAGPaOR$`95%CI`[38], hcovAGPaOR$`95%CI`[39], hcovAGPaOR$`95%CI`[40], hcovAGPaOR$`95%CI`[41], hcovAGPaOR$`95%CI`[42], hcovAGPaOR$`95%CI`[43], hcovAGPaOR$`95%CI`[44], hcovAGPaOR$`95%CI`[45], hcovAGPaOR$`95%CI`[46], NA, hcovAGPaOR$`95%CI`[47], NA, hcovAGPaOR$`95%CI`[48], NA, hcovAGPaOR$`95%CI`[49], hcovAGPaOR$`95%CI`[50], hcovAGPaOR$`95%CI`[51], hcovAGPaOR$`95%CI`[52], NA, hcovAGPaOR$`95%CI`[53], NA, hcovAGPaOR$`95%CI`[54]),
  
  "adjpvalue" = c(hcovAGPaOR$`p-value`[2], NA, hcovAGPaOR$`p-value`[3], NA, hcovAGPaOR$`p-value`[4], hcovAGPaOR$`p-value`[5], NA, hcovAGPaOR$`p-value`[6], hcovAGPaOR$`p-value`[7], hcovAGPaOR$`p-value`[8], hcovAGPaOR$`p-value`[9], hcovAGPaOR$`p-value`[10], hcovAGPaOR$`p-value`[11], hcovAGPaOR$`p-value`[12], hcovAGPaOR$`p-value`[13], hcovAGPaOR$`p-value`[14], hcovAGPaOR$`p-value`[15], hcovAGPaOR$`p-value`[16], hcovAGPaOR$`p-value`[17], hcovAGPaOR$`p-value`[18], NA, hcovAGPaOR$`p-value`[19], hcovAGPaOR$`p-value`[20], hcovAGPaOR$`p-value`[21], NA, hcovAGPaOR$`p-value`[22], hcovAGPaOR$`p-value`[23], hcovAGPaOR$`p-value`[24], NA, hcovAGPaOR$`p-value`[25], hcovAGPaOR$`p-value`[26], hcovAGPaOR$`p-value`[27], NA, hcovAGPaOR$`p-value`[28], hcovAGPaOR$`p-value`[29], hcovAGPaOR$`p-value`[30], hcovAGPaOR$`p-value`[31], NA, hcovAGPaOR$`p-value`[32], NA, hcovAGPaOR$`p-value`[33], hcovAGPaOR$`p-value`[34], hcovAGPaOR$`p-value`[35], hcovAGPaOR$`p-value`[36], hcovAGPaOR$`p-value`[37], hcovAGPaOR$`p-value`[38], hcovAGPaOR$`p-value`[39], hcovAGPaOR$`p-value`[40], hcovAGPaOR$`p-value`[41], hcovAGPaOR$`p-value`[42], hcovAGPaOR$`p-value`[43], hcovAGPaOR$`p-value`[44], hcovAGPaOR$`p-value`[45], hcovAGPaOR$`p-value`[46], NA, hcovAGPaOR$`p-value`[47], NA, hcovAGPaOR$`p-value`[48], NA, hcovAGPaOR$`p-value`[49], hcovAGPaOR$`p-value`[50], hcovAGPaOR$`p-value`[51], hcovAGPaOR$`p-value`[52], NA, hcovAGPaOR$`p-value`[53], NA, hcovAGPaOR$`p-value`[54]))

agptrial$adjpvalue[agptrial$adjpvalue<0.001] <- "<0.001"
agptrial[is.na(agptrial)] <- "Ref"

##create gt table for AGP MODEL
gthcovidagpOR <- agptrial %>% 
  gt(groupname_col = "groups") %>%
  tab_header(
    title = "eTable 9. Multivariable logistic regression model including AGPs to which healthcare workers were regularly exposed to when performed in suspected or confirmed COVID-19 patients",
    subtitle = "") %>%
  tab_stubhead(label = "") %>% 
  cols_label(
    rownames = "",
    multivariate.OR = "Multivariable adjusted OR",
    X95CI = "95%CI",
    adjpvalue = md("*p*-value")) %>% 
  cols_align(align = "center", columns = vars(multivariate.OR, X95CI, adjpvalue)) %>% 
  tab_footnote(
    footnote = "Adjusted for all the above listed variables using multivariable logistic regression",
    locations = cells_column_labels(columns = vars(multivariate.OR))) %>% 
  tab_source_note(source_note = md("Multivariate odds ratio (OR), 95% confidence intervals (95%CI)  
                                   Ref = Reference value")) %>% 
  tab_options(heading.align = "left") %>% 
  tab_style(
    style = cell_text(style = "italic", indent = pct(2.5)),
    locations = cells_body(columns = vars(rownames))
  )


#gt for TABLE: "Laboratory-confirmed SARS-CoV-2 Outcome"
##initialise
covidpositrial <- data.frame(groups = c(
  "Age",
  rep("Sex", times = 2),
  rep("Ethnicity", times = 3),
  rep("Household - Persons", times = 3),
  rep("Comorbidities", times = 11),
  rep("Smoking status", times = 4),
  rep("Country", times = 4),
  rep("Main Healthcare Facility", times = 4),
  rep("Role Group", times = 5),
  rep("Public Transport to travel to work", times = 2),
  rep("Regular clinical contact with COVID-19 patients", times =2),
  rep("Regular exposure to AGP(s) performed in COVID-19 patients", times = 2),
  rep("Sufficient training in PPE usage", times = 2),
  rep("Lacked access to PPE items for clinical contact", times = 2),
  rep("Clinical contact without adequate PPE", times = 5),
  rep("Reused disposable PPE", times = 2),
  rep("Used improvised PPE", times = 2)),
  
  "rownames" = c("Age", "Female", "Male", "White", "BAME", "Prefer not to say", "Lives alone", "Lives with 1 or more persons; no children", "Lives with 1 or more persons; has children", "Hypertension", "Diabetes", "Cancer", "Heart disease", "Immunosuppression", "Respiratory disease", "Renal disease", "Liver disease", "Neurological disease", "Obesity", "Prefer not to say", "Never smoked", "Current or Ex-smoker within 1 year", "Ex-smoker > 1 year", "Prefer not to say", "England", "Northern Ireland", "Scotland", "Wales", "Hospital", "Community healthcare facility", "Other", "Social care facility", "Nurses, midwives and associated staff", "Allied health professionals", "Dentists and dental staff", "Doctors", "Other", "No", "Yes", "No", "Yes", "No", "Yes", "No", "Yes", "No", "Yes", "Never", "Rarely", "Sometimes", "Often", "Always", "No", "Yes", "No", "Yes"),
  
  "multivariate.OR" = c(hcovidposiglm$`adjusted OR`[2], NA, hcovidposiglm$`adjusted OR`[3], NA, hcovidposiglm$`adjusted OR`[4], hcovidposiglm$`adjusted OR`[5], NA, hcovidposiglm$`adjusted OR`[6], hcovidposiglm$`adjusted OR`[7], hcovidposiglm$`adjusted OR`[8], hcovidposiglm$`adjusted OR`[9], hcovidposiglm$`adjusted OR`[10], hcovidposiglm$`adjusted OR`[11], hcovidposiglm$`adjusted OR`[12], hcovidposiglm$`adjusted OR`[13], hcovidposiglm$`adjusted OR`[14], hcovidposiglm$`adjusted OR`[15], hcovidposiglm$`adjusted OR`[16], hcovidposiglm$`adjusted OR`[17], hcovidposiglm$`adjusted OR`[18], NA, hcovidposiglm$`adjusted OR`[19], hcovidposiglm$`adjusted OR`[20], hcovidposiglm$`adjusted OR`[21], NA, hcovidposiglm$`adjusted OR`[22], hcovidposiglm$`adjusted OR`[23], hcovidposiglm$`adjusted OR`[24], NA, hcovidposiglm$`adjusted OR`[25], hcovidposiglm$`adjusted OR`[26], hcovidposiglm$`adjusted OR`[27], NA, hcovidposiglm$`adjusted OR`[28], hcovidposiglm$`adjusted OR`[29], hcovidposiglm$`adjusted OR`[30], hcovidposiglm$`adjusted OR`[31], NA, hcovidposiglm$`adjusted OR`[32], NA, hcovidposiglm$`adjusted OR`[33], NA, hcovidposiglm$`adjusted OR`[34], NA, hcovidposiglm$`adjusted OR`[35], NA, hcovidposiglm$`adjusted OR`[36], NA, hcovidposiglm$`adjusted OR`[37], hcovidposiglm$`adjusted OR`[38], hcovidposiglm$`adjusted OR`[39], hcovidposiglm$`adjusted OR`[40], NA, hcovidposiglm$`adjusted OR`[41], NA, hcovidposiglm$`adjusted OR`[42]),
  
  "95CI" = c(hcovidposiaOR$`95%CI`[2], NA, hcovidposiaOR$`95%CI`[3], NA, hcovidposiaOR$`95%CI`[4], hcovidposiaOR$`95%CI`[5], NA, hcovidposiaOR$`95%CI`[6], hcovidposiaOR$`95%CI`[7], hcovidposiaOR$`95%CI`[8], hcovidposiaOR$`95%CI`[9], hcovidposiaOR$`95%CI`[10], hcovidposiaOR$`95%CI`[11], hcovidposiaOR$`95%CI`[12], hcovidposiaOR$`95%CI`[13], hcovidposiaOR$`95%CI`[14], hcovidposiaOR$`95%CI`[15], hcovidposiaOR$`95%CI`[16], hcovidposiaOR$`95%CI`[17], hcovidposiaOR$`95%CI`[18], NA, hcovidposiaOR$`95%CI`[19], hcovidposiaOR$`95%CI`[20], hcovidposiaOR$`95%CI`[21], NA, hcovidposiaOR$`95%CI`[22], hcovidposiaOR$`95%CI`[23], hcovidposiaOR$`95%CI`[24], NA, hcovidposiaOR$`95%CI`[25], hcovidposiaOR$`95%CI`[26], hcovidposiaOR$`95%CI`[27], NA, hcovidposiaOR$`95%CI`[28], hcovidposiaOR$`95%CI`[29], hcovidposiaOR$`95%CI`[30], hcovidposiaOR$`95%CI`[31], NA, hcovidposiaOR$`95%CI`[32], NA, hcovidposiaOR$`95%CI`[33], NA, hcovidposiaOR$`95%CI`[34], NA, hcovidposiaOR$`95%CI`[35], NA, hcovidposiaOR$`95%CI`[36], NA, hcovidposiaOR$`95%CI`[37], hcovidposiaOR$`95%CI`[38], hcovidposiaOR$`95%CI`[39], hcovidposiaOR$`95%CI`[40], NA, hcovidposiaOR$`95%CI`[41], NA, hcovidposiaOR$`95%CI`[42]),
  
  "adjpvalue" = c(hcovidposiaOR$`p-value`[2], NA, hcovidposiaOR$`p-value`[3], NA, hcovidposiaOR$`p-value`[4], hcovidposiaOR$`p-value`[5], NA, hcovidposiaOR$`p-value`[6], hcovidposiaOR$`p-value`[7], hcovidposiaOR$`p-value`[8], hcovidposiaOR$`p-value`[9], hcovidposiaOR$`p-value`[10], hcovidposiaOR$`p-value`[11], hcovidposiaOR$`p-value`[12], hcovidposiaOR$`p-value`[13], hcovidposiaOR$`p-value`[14], hcovidposiaOR$`p-value`[15], hcovidposiaOR$`p-value`[16], hcovidposiaOR$`p-value`[17], hcovidposiaOR$`p-value`[18], NA, hcovidposiaOR$`p-value`[19], hcovidposiaOR$`p-value`[20], hcovidposiaOR$`p-value`[21], NA, hcovidposiaOR$`p-value`[22], hcovidposiaOR$`p-value`[23], hcovidposiaOR$`p-value`[24], NA, hcovidposiaOR$`p-value`[25], hcovidposiaOR$`p-value`[26], hcovidposiaOR$`p-value`[27], NA, hcovidposiaOR$`p-value`[28], hcovidposiaOR$`p-value`[29], hcovidposiaOR$`p-value`[30], hcovidposiaOR$`p-value`[31], NA, hcovidposiaOR$`p-value`[32], NA, hcovidposiaOR$`p-value`[33], NA, hcovidposiaOR$`p-value`[34], NA, hcovidposiaOR$`p-value`[35], NA, hcovidposiaOR$`p-value`[36], NA, hcovidposiaOR$`p-value`[37], hcovidposiaOR$`p-value`[38], hcovidposiaOR$`p-value`[39], hcovidposiaOR$`p-value`[40], NA, hcovidposiaOR$`p-value`[41], NA, hcovidposiaOR$`p-value`[42]))

covidpositrial$adjpvalue[covidpositrial$adjpvalue<0.001] <- "<0.001"
covidpositrial[is.na(covidpositrial)] <- "Ref"

##create gt table for COVID POSITIVE MODEL
gthcovidposiaOR <- covidpositrial %>% 
  gt(groupname_col = "groups") %>%
  tab_header(
    title = "eTable 10. Multivariable logistic regression model with the outcome being participants stating that they had laboratory-confirmed SARS-CoV-2 infection (via reverse transcription polymerase chain reaction or antibody testing)",
    subtitle = "") %>%
  tab_stubhead(label = "") %>% 
  cols_label(
    rownames = "",
    multivariate.OR = "Multivariable adjusted OR",
    X95CI = "95%CI",
    adjpvalue = md("*p*-value")) %>% 
  cols_align(align = "center", columns = vars(multivariate.OR, X95CI, adjpvalue)) %>% 
  tab_footnote(
    footnote = "Adjusted for all the above listed variables using multivariable logistic regression",
    locations = cells_column_labels(columns = vars(multivariate.OR))) %>% 
  tab_source_note(source_note = md("Multivariate odds ratio (OR), 95% confidence intervals (95%CI)  
                                   Ref = Reference value")) %>% 
  tab_options(heading.align = "left") %>% 
  tab_style(
    style = cell_text(style = "italic", indent = pct(2.5)),
    locations = cells_body(columns = vars(rownames))
  )


#TIME OUT
print(gthcovidbameOR)
print(gthcovidsmokerOR)
print(gthcovidareaOR)
print(gthcovidagpOR)
print(gthcovidposiaOR)

#DEFORMATION