#START UP [Statistical Analyses]
library(tidyverse)
library(lubridate)
library(pROC)
library(jtools) #customised summary of glm tables
library(qwraps2) #tables
library(gt) #tables


#Define markup language
options(qwraps2_markup = "markdown")

#Load data
hcovidfull <- read.csv("data/hcovid_clean.csv", header = TRUE, check.names = FALSE, stringsAsFactors = FALSE)

#Initialise
##convert relevant vectors to factors and re-order/relevel
hcovidfull$EthnicMain <- as.factor(hcovidfull$EthnicMain)
hcovidfull$EthnicMain <- relevel(hcovidfull$EthnicMain, "White")

hcovidfull$EthnicBAME <- as.factor(hcovidfull$EthnicBAME)
hcovidfull$EthnicBAME <- factor(hcovidfull$EthnicBAME, levels = c("White", "BAME", "Prefer not to say"))

hcovidfull$hChildrenDef <- as.factor(hcovidfull$hChildrenDef)
hcovidfull$hChildrenDef <- factor(hcovidfull$hChildrenDef, levels = c("Lives alone", "No children", "Has children"))

hcovidfull$Smoker <- as.factor(hcovidfull$Smoker)
hcovidfull$Smoker <- factor(hcovidfull$Smoker, levels = c("Never smoked", "Current smoker or Ex-smoker (within 1 year)", "Ex-smoker (more than 1 year)", "Prefer not to say")) 

hcovidfull$RoleGroup <- as.factor(hcovidfull$RoleGroup)
hcovidfull$RoleGroup <- relevel(hcovidfull$RoleGroup, "Nurses, midwives and associated staff")

hcovidfull$Grade <- as.factor(hcovidfull$Grade)
hcovidfull$Grade <- relevel(hcovidfull$Grade, "Consultant")

hcovidfull$PSDoc <- as.factor(hcovidfull$PSDoc)
hcovidfull$PSDoc <- relevel(hcovidfull$PSDoc, "Anaesthetics")

hcovidfull$PSMinor <- as.factor(hcovidfull$PSMinor)
hcovidfull$PSMinor <- relevel(hcovidfull$PSMinor, "Medical")

hcovidfull$Facility <- as.factor(hcovidfull$Facility)
hcovidfull$Facility <- relevel(hcovidfull$Facility, "Hospital")

hcovidfull$ExposureComp <- as.factor(hcovidfull$ExposureComp)
hcovidfull$ExposureComp <- factor(hcovidfull$ExposureComp, level = c("None", "Clinical contact only", "AGP exposure only", "Clinical contact and AGP exposure"))

hcovidfull$AreaDef <- as.factor(hcovidfull$AreaDef)
hcovidfull$AreaDef <- factor(hcovidfull$AreaDef, level = c("None", "One", "Two", "Three or more")) 

hcovidfull$AGPDef <- as.factor(hcovidfull$AGPDef)
hcovidfull$AGPDef <- factor(hcovidfull$AGPDef, level = c("None", "One", "Two or more")) 

hcovidfull$NoPPEexpofreq[is.na(hcovidfull$NoPPEexpofreq)] <- "Never"
hcovidfull$NoPPEexpofreq <- as.factor(hcovidfull$NoPPEexpofreq)
hcovidfull$NoPPEexpofreq <- factor(hcovidfull$NoPPEexpofreq, level = c("Never", "Rarely", "Sometimes", "Often", "Always")) 

##data frame formation
hcovidsi <- hcovidfull %>% filter(CompSI == TRUE)
hcovidhosp <- hcovidfull %>% filter(CompHosp == TRUE)
hcovidpos <- hcovidfull %>% filter(CompPosi == TRUE)
hcovidcompout <- hcovidfull %>% filter(CompOut == TRUE)
hcovidtest <- hcovidfull %>% filter(TestOutcome !="Untested") #not required for composites


#"Feel" for the data
##age
ggplot(data = hcovidfull, aes(x = Age, y = as.numeric(CompOut))) + 
  geom_point() + 
  geom_smooth(method = "loess")

##comorbiditytotal
scatter.smooth(jitter(as.numeric(hcovidfull$CompOut)) ~ jitter(hcovidfull$ComorbidityTotal), family = "gaussian", lpars = list(col = "red"))

##agptotal
scatter.smooth(jitter(as.numeric(hcovidfull$CompOut)) ~ jitter(hcovidfull$AGPTotal), family = "gaussian", lpars = list(col = "red"))

##areatotal
scatter.smooth(jitter(as.numeric(hcovidfull$CompOut)) ~ jitter(hcovidfull$AreaTotal), family = "gaussian", lpars = list(col = "red"))

##ppelacktotal
scatter.smooth(jitter(as.numeric(hcovidfull$CompOut)) ~ jitter(hcovidfull$PPELackTotal), family = "gaussian", lpars = list(col = "red"))


#glm for SUMMARY --> COMPOSITE
##FULL MODEL (a.k.a. 'Model 3.7')
hcovidfullglm37 <- glm(CompOut ~ Age + Sex + EthnicBAME + hChildrenDef + Hypertension + Diabetes + Cancer + `Heart disease` + Immunosuppression + `Respiratory disease` + `Renal disease` + `Liver disease` + `Neurological disease` + `Obesity` + `Prefer not to say` + Smoker + Country + Facility + RoleGroup + PublicTransport + contactCOVID + AGPExpo + PPETraining + PPELack + NoPPEexpofreq + ReusePPE + CustomPPE, data = hcovidfull, family = binomial)

##jtools summary with OR for FULL MODEL
summ(hcovidfullglm37, exp = TRUE, digits = 3) #jtools summary with OR

##dataframe summary with OR for FULL MODEL
fullPvals <- as.data.frame(coef(summary(hcovidfullglm37))[, 4])
hcovidfullaOR <- as.data.frame(round(exp(cbind(coef(hcovidfullglm37), confint(hcovidfullglm37))), digits = 2))
hcovidfullaOR <- hcovidfullaOR %>% 
  rownames_to_column("Variables") %>%
  rename(`adjusted OR` = V1) %>%
  mutate(`95%CI` = paste(hcovidfullaOR$`2.5 %`, hcovidfullaOR$`97.5 %`, sep = "-")) %>% 
  mutate("p-value" = round(fullPvals$`coef(summary(hcovidfullglm37))[, 4]`, digits = 3)) %>% 
  subset(., select = -c(`2.5 %`, `97.5 %`)) %>% 
  mutate(sig = `p-value` < 0.05)
view(hcovidfullaOR)
view(filter(hcovidfullaOR, sig == TRUE))

#roc and auroc
##fitted probabilities for FULL MODEL
PredCompOut <- predict(hcovidfullglm37, type = c("response"))

##roc plot for FULL MODEL
hcovidfullroc <- pROC::roc(hcovidfull$CompOut ~ PredCompOut, hcovidfull)
plot(hcovidfullroc)

##auroc for FULL MODEL
###[Note: qwraps2 also uses auc; hence need to define pROC]
pROC::auc(hcovidfullroc)


#gt for TABLE: Outcomes & Composite Outcome Summary
##initialise
trial <- data.frame(groups = c(
  "Age",
  rep("Sex", times = 2),
  rep("Ethnicity", times = 3),
  rep("Household - Persons", times = 3),
  rep("Comorbidities", times = 11),
  rep("Smoking status", times = 4),
  rep("Country", times = 4),
  rep("Main Healthcare Facility", times = 4),
  rep("Role Group", times = 5),
  rep("Public Transport to travel to work", times = 2),
  rep("Regular clinical contact with COVID-19 patients", times =2),
  rep("Regular exposure to AGP(s) performed in COVID-19 patients", times = 2),
  rep("Sufficient training in PPE usage", times = 2),
  rep("Lacked access to PPE items for clinical contact", times = 2),
  rep("Clinical contact without adequate PPE", times = 5),
  rep("Reused disposable PPE", times = 2),
  rep("Used improvised PPE", times = 2)),
  
  "rownames" = c("Age", "Female", "Male", "White", "BAME", "Prefer not to say", "Lives alone", "Lives with 1 or more persons; no children", "Lives with 1 or more persons; has children", "Hypertension", "Diabetes", "Cancer", "Heart disease", "Immunosuppression", "Respiratory disease", "Renal disease", "Liver disease", "Neurological disease", "Obesity", "Prefer not to say", "Never smoked", "Current or Ex-smoker within 1 year", "Ex-smoker > 1 year", "Prefer not to say", "England", "Northern Ireland", "Scotland", "Wales", "Hospital", "Community healthcare facility", "Other", "Social care facility", "Nurses, midwives and associated staff", "Allied health professionals", "Dentists and dental staff", "Doctors", "Other", "No", "Yes", "No", "Yes", "No", "Yes", "No", "Yes", "No", "Yes", "Never", "Rarely", "Sometimes", "Often", "Always", "No", "Yes", "No", "Yes"),
  
  "univariate.OR" = c(NA, NA, Sex.csprop$OR[2], NA, EthnicBAME.csprop$OR[2],  EthnicBAME.csprop$OR[3], NA, hChildrenDef.csprop$OR[2], hChildrenDef.csprop$OR[3], Hypertension.csprop$OR[2], Diabetes.csprop$OR[2], Cancer.csprop$OR[2], Heartdisease.csprop$OR[2], Immunosuppression.csprop$OR[2], Respdisease.csprop$OR[2], Renaldisease.csprop$OR[2], Liverdisease.csprop$OR[2], Neurodisease.csprop$OR[2], Obesity.csprop$OR[2], Prefernottosay.csprop$OR[2], NA, Smoker.csprop$OR[2], Smoker.csprop$OR[3], Smoker.csprop$OR[4], NA, Country.csprop$OR[2], Country.csprop$OR[3], Country.csprop$OR[4], NA, Facility.csprop$OR[2], Facility.csprop$OR[3], Facility.csprop$OR[4], NA, RoleGroup.csprop$OR[2], RoleGroup.csprop$OR[3], RoleGroup.csprop$OR[4], RoleGroup.csprop$OR[5], NA, PublicTransport.csprop$OR[2], NA, contactCOVID.csprop$OR[2], NA, AGPExpo.csprop$OR[2], NA, PPETraining.csprop$OR[2], NA, PPELack.csprop$OR[2], NA, NoPPEexpofreq.csprop$OR[2], NoPPEexpofreq.csprop$OR[3], NoPPEexpofreq.csprop$OR[4], NoPPEexpofreq.csprop$OR[5], NA, ReusePPE.csprop$OR[2], NA, CustomPPE.csprop$OR[2]),
  
  "unipvalue" = c(NA, NA, Sex.csprop$chi[2], NA, EthnicBAME.csprop$chi[2],  EthnicBAME.csprop$chi[3], NA, hChildrenDef.csprop$chi[2], hChildrenDef.csprop$chi[3], Hypertension.csprop$chi[2], Diabetes.csprop$chi[2], Cancer.csprop$chi[2], Heartdisease.csprop$chi[2], Immunosuppression.csprop$chi[2], Respdisease.csprop$chi[2], Renaldisease.csprop$chi[2], Liverdisease.csprop$chi[2], Neurodisease.csprop$chi[2], Obesity.csprop$chi[2], Prefernottosay.csprop$chi[2], NA, Smoker.csprop$chi[2], Smoker.csprop$chi[3], Smoker.csprop$chi[4], NA, Country.csprop$chi[2], Country.csprop$chi[3], Country.csprop$chi[4], NA, Facility.csprop$chi[2], Facility.csprop$chi[3], Facility.csprop$chi[4], NA, RoleGroup.csprop$chi[2], RoleGroup.csprop$chi[3], RoleGroup.csprop$chi[4], RoleGroup.csprop$chi[5], NA, PublicTransport.csprop$chi[2], NA, contactCOVID.csprop$chi[2], NA, AGPExpo.csprop$chi[2], NA, PPETraining.csprop$chi[2], NA, PPELack.csprop$chi[2], NA, NoPPEexpofreq.csprop$chi[2], NoPPEexpofreq.csprop$chi[3], NoPPEexpofreq.csprop$chi[4], NoPPEexpofreq.csprop$chi[5], NA, ReusePPE.csprop$chi[2], NA, CustomPPE.csprop$chi[2]),
  
  "multivariate.OR" = c(hcovidfullaOR$`adjusted OR`[2], NA, hcovidfullaOR$`adjusted OR`[3], NA, hcovidfullaOR$`adjusted OR`[4], hcovidfullaOR$`adjusted OR`[5], NA, hcovidfullaOR$`adjusted OR`[6], hcovidfullaOR$`adjusted OR`[7], hcovidfullaOR$`adjusted OR`[8], hcovidfullaOR$`adjusted OR`[9], hcovidfullaOR$`adjusted OR`[10], hcovidfullaOR$`adjusted OR`[11], hcovidfullaOR$`adjusted OR`[12], hcovidfullaOR$`adjusted OR`[13], hcovidfullaOR$`adjusted OR`[14], hcovidfullaOR$`adjusted OR`[15], hcovidfullaOR$`adjusted OR`[16], hcovidfullaOR$`adjusted OR`[17], hcovidfullaOR$`adjusted OR`[18], NA, hcovidfullaOR$`adjusted OR`[19], hcovidfullaOR$`adjusted OR`[20], hcovidfullaOR$`adjusted OR`[21], NA, hcovidfullaOR$`adjusted OR`[22], hcovidfullaOR$`adjusted OR`[23], hcovidfullaOR$`adjusted OR`[24], NA, hcovidfullaOR$`adjusted OR`[25], hcovidfullaOR$`adjusted OR`[26], hcovidfullaOR$`adjusted OR`[27], NA, hcovidfullaOR$`adjusted OR`[28], hcovidfullaOR$`adjusted OR`[29], hcovidfullaOR$`adjusted OR`[30], hcovidfullaOR$`adjusted OR`[31], NA, hcovidfullaOR$`adjusted OR`[32], NA, hcovidfullaOR$`adjusted OR`[33], NA, hcovidfullaOR$`adjusted OR`[34], NA, hcovidfullaOR$`adjusted OR`[35], NA, hcovidfullaOR$`adjusted OR`[36], NA, hcovidfullaOR$`adjusted OR`[37], hcovidfullaOR$`adjusted OR`[38], hcovidfullaOR$`adjusted OR`[39], hcovidfullaOR$`adjusted OR`[40], NA, hcovidfullaOR$`adjusted OR`[41], NA, hcovidfullaOR$`adjusted OR`[42]),
  
  "95CI" = c(hcovidfullaOR$`95%CI`[2], NA, hcovidfullaOR$`95%CI`[3], NA, hcovidfullaOR$`95%CI`[4], hcovidfullaOR$`95%CI`[5], NA, hcovidfullaOR$`95%CI`[6], hcovidfullaOR$`95%CI`[7], hcovidfullaOR$`95%CI`[8], hcovidfullaOR$`95%CI`[9], hcovidfullaOR$`95%CI`[10], hcovidfullaOR$`95%CI`[11], hcovidfullaOR$`95%CI`[12], hcovidfullaOR$`95%CI`[13], hcovidfullaOR$`95%CI`[14], hcovidfullaOR$`95%CI`[15], hcovidfullaOR$`95%CI`[16], hcovidfullaOR$`95%CI`[17], hcovidfullaOR$`95%CI`[18], NA, hcovidfullaOR$`95%CI`[19], hcovidfullaOR$`95%CI`[20], hcovidfullaOR$`95%CI`[21], NA, hcovidfullaOR$`95%CI`[22], hcovidfullaOR$`95%CI`[23], hcovidfullaOR$`95%CI`[24], NA, hcovidfullaOR$`95%CI`[25], hcovidfullaOR$`95%CI`[26], hcovidfullaOR$`95%CI`[27], NA, hcovidfullaOR$`95%CI`[28], hcovidfullaOR$`95%CI`[29], hcovidfullaOR$`95%CI`[30], hcovidfullaOR$`95%CI`[31], NA, hcovidfullaOR$`95%CI`[32], NA, hcovidfullaOR$`95%CI`[33], NA, hcovidfullaOR$`95%CI`[34], NA, hcovidfullaOR$`95%CI`[35], NA, hcovidfullaOR$`95%CI`[36], NA, hcovidfullaOR$`95%CI`[37], hcovidfullaOR$`95%CI`[38], hcovidfullaOR$`95%CI`[39], hcovidfullaOR$`95%CI`[40], NA, hcovidfullaOR$`95%CI`[41], NA, hcovidfullaOR$`95%CI`[42]),
  
  "adjpvalue" = c(hcovidfullaOR$`p-value`[2], NA, hcovidfullaOR$`p-value`[3], NA, hcovidfullaOR$`p-value`[4], hcovidfullaOR$`p-value`[5], NA, hcovidfullaOR$`p-value`[6], hcovidfullaOR$`p-value`[7], hcovidfullaOR$`p-value`[8], hcovidfullaOR$`p-value`[9], hcovidfullaOR$`p-value`[10], hcovidfullaOR$`p-value`[11], hcovidfullaOR$`p-value`[12], hcovidfullaOR$`p-value`[13], hcovidfullaOR$`p-value`[14], hcovidfullaOR$`p-value`[15], hcovidfullaOR$`p-value`[16], hcovidfullaOR$`p-value`[17], hcovidfullaOR$`p-value`[18], NA, hcovidfullaOR$`p-value`[19], hcovidfullaOR$`p-value`[20], hcovidfullaOR$`p-value`[21], NA, hcovidfullaOR$`p-value`[22], hcovidfullaOR$`p-value`[23], hcovidfullaOR$`p-value`[24], NA, hcovidfullaOR$`p-value`[25], hcovidfullaOR$`p-value`[26], hcovidfullaOR$`p-value`[27], NA, hcovidfullaOR$`p-value`[28], hcovidfullaOR$`p-value`[29], hcovidfullaOR$`p-value`[30], hcovidfullaOR$`p-value`[31], NA, hcovidfullaOR$`p-value`[32], NA, hcovidfullaOR$`p-value`[33], NA, hcovidfullaOR$`p-value`[34], NA, hcovidfullaOR$`p-value`[35], NA, hcovidfullaOR$`p-value`[36], NA, hcovidfullaOR$`p-value`[37], hcovidfullaOR$`p-value`[38], hcovidfullaOR$`p-value`[39], hcovidfullaOR$`p-value`[40], NA, hcovidfullaOR$`p-value`[41], NA, hcovidfullaOR$`p-value`[42]))

trial$unipvalue[trial$unipvalue<0.001] <- "<0.001"
trial$adjpvalue[trial$adjpvalue<0.001] <- "<0.001"
trial[is.na(trial)] <- "Ref"

##create gt table for each outcome and composite
gthcovidfullOR <- trial %>% 
  gt(groupname_col = "groups") %>%
  tab_header(
    title = "Table 2. Variables and association with composite outcome",
    subtitle = "") %>%
  tab_stubhead(label = "") %>% 
  cols_label(
    rownames = "",
    univariate.OR = "Univariate OR",
    unipvalue = md("*p*-value"),
    multivariate.OR = "Multivariate OR",
    X95CI = "95%CI",
    adjpvalue = md("*p*-value")) %>% 
  cols_align(align = "center", columns = vars(univariate.OR, unipvalue, multivariate.OR, X95CI, adjpvalue)) %>% 
  tab_footnote(
    footnote = "Adjusted for all the above listed variables using multivariable logistic regression",
    locations = cells_column_labels(columns = vars(multivariate.OR))) %>% 
  tab_source_note(source_note = md("Univariate and multivariate odds ratio (OR), 95% confidence intervals (95%CI)  
                                   Ref = Reference value")) %>% 
  tab_options(heading.align = "left") %>% 
  tab_style(
    style = cell_text(style = "italic", indent = pct(2.5)),
    locations = cells_body(columns = vars(rownames))
  )


#TIME OUT
print(gthcovidfullOR)


#DEFORMATION