#START UP [Statistical Analyses - Graphs]
library(tidyverse)
#library(reshape2) #may not actually be required...
library(lubridate) #date and time
library(ggplot2) #graphs
library(viridis) #graph colours
library(RColorBrewer) #graph colours


#Load data
hcovidfull <- read.csv("data/hcovid_clean.csv", header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)


#Initialise
#main df formations
hcovidsi <- hcovidfull %>% filter(CompSI == TRUE)
hcovidhosp <- hcovidfull %>% filter(CompHosp == TRUE)
hcovidpos <- hcovidfull %>% filter(CompPosi == TRUE)
hcovidcompout <- hcovidfull %>% filter(CompOut == TRUE)
hcovidtest <- hcovidfull %>% filter(TestOutcome !="Untested") #not required for composites


#Graphs for manuscript
##df formation for *Facility* with CompOut
facilityfull <- hcovidfull %>% count(Facility) %>% rename("All" = n)
facilitycompout <- hcovidcompout %>% count(Facility) %>% rename("COVID-19 Composite" = n)
facilitymerge <- merge(facilityfull, facilitycompout, by = "Facility")

facilitymerge.summary <- pivot_longer(facilitymerge, -Facility, names_to = "Group", values_to = "Frequency")
facilitymerge.summary <- facilitymerge.summary %>% mutate(Percentage = Frequency/nrow(hcovidfull))
facilitymerge.summary <- facilitymerge.summary[order(facilitymerge.summary$`Frequency`, decreasing = FALSE),]
#trailing comma to select all columns!
facilitymerge.summary$Facility <- as.factor(facilitymerge.summary$Facility)
facilitymerge.summary$Facility <- relevel(facilitymerge.summary$Facility, "Hospital")

##bar graph for main healthcare facility --> Figure 2
facilityoutcomes.graph = facilitymerge.summary %>%
  ggplot(aes(fill = Group, x = Facility, y = Percentage)) + 
  geom_col(colour = "black", position = "dodge") +
  geom_text(aes(label = scales::percent(Percentage, accuracy = 1)), position = position_dodge(width = 0.9), vjust = -0.5, colour = "black", size = 5, fontface='bold') +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1), expand = c(0, 0), limits = c(0, 1.03)) +
  labs(y = "Proportion of respondents (%)", fill = "Group:") +
  theme(plot.title = element_text(size = 20, face="bold"),
        axis.line = element_line(colour = "black"),
        axis.text = element_text(size=14, face="bold"),
        axis.title = element_text(size=18,face="bold"),
        axis.title.x = element_blank(),
        legend.title = element_blank(),
        legend.text = element_text(size = 14, face="bold"),
        legend.position = "bottom",
        panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank()) +
  scale_fill_brewer(palette = "Dark2")
print(facilityoutcomes.graph)


##df formation for Lacking PPE Items
LackPPEItems.data <- hcovidfull %>% 
  select("S_ID", "Eyewear":"PAPR") %>% 
  na.omit(.)
LackPPEItems.data$`Lack PPEItems Total` <- rowSums(LackPPEItems.data[-1] == TRUE)
LackPPEItems.data <- LackPPEItems.data %>% 
  rename("Eye protection" = Eyewear, "Respirator face mask" = RespiratorMask, "Type IIR face mask" = SurgicalMaskFR, "Standard face mask" = SurgicalMaskStandard, "Plastic apron" = Apron)

LackPPEItems.summary <- LackPPEItems.data %>%
  select("Eye protection":"PAPR") %>% 
  t(.) %>% 
  as.data.frame()
LackPPEItems.summary <- cbind(LackPPEItems.summary, Total = rowSums(LackPPEItems.summary))
LackPPEItems.summary <- LackPPEItems.summary %>% 
  subset(., select = Total) %>% 
  rownames_to_column(., "PPE Items")
names(LackPPEItems.summary)[names(LackPPEItems.summary) == "Total"] <- "Frequency"
LackPPEItems.summary <- LackPPEItems.summary[order(LackPPEItems.summary$`Frequency`, decreasing = FALSE),]
LackPPEItems.summary$`PPE Items` <- factor(LackPPEItems.summary$`PPE Items`, levels = LackPPEItems.summary$`PPE Items`)
LackPPEItems.summary <- LackPPEItems.summary %>% mutate(Percentage = Frequency/sum(hcovidfull$PPELack == "Yes"))

LackPPEItems.cumulcount = count(LackPPEItems.data, `Lack PPEItems Total`) #LackPPEItems Count Table

##barchart of Lacking PPE Items --> Figure 3
LackPPEItems.graph = LackPPEItems.summary %>% 
  ggplot(aes(x = `PPE Items`, y = Percentage)) + 
  geom_col(fill = "#1B9E77", colour = "black") +
  geom_text(aes(label = scales::percent(Percentage, accuracy = 1)), position = position_dodge(width = 1), hjust = -0.2, colour = "black", size = 5, fontface='bold') +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1), expand = c(0, 0), limits = c(0, 0.83)) +
  labs(x = "PPE Item", y = "% of participants lacking PPE") +
  coord_flip() +
  theme(plot.title = element_text(size = 20, face="bold"),
        axis.line = element_line(colour = "black"),
        axis.text = element_text(size=14, face="bold"),
        axis.title = element_text(size=18,face="bold"),
        panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank())
print(LackPPEItems.graph)


#Graphs for supplement material
##df formation for Location of clinical contact
Area.data <- hcovidfull %>% 
  select("S_ID", "COVID19zone":"OtherArea") %>% 
  na.omit(.)
Area.data$`Area Total` <- rowSums(Area.data[-1] == TRUE)
Area.data <- Area.data %>% 
  rename("COVID-19 zone" = `COVID19zone`, "Care/Nursing home" = CareHome, "Inpatient clinic" = InpClinic, "Outpatient clinic" = OutClinic, "Endoscopy" = EndoscopyArea, "GP practice" = GP, "Home visits" = HomeVisits, "ICU/HDU" = ICU, "Inpatient ward (non-COVID)" = InpWardnonCOVID, "Operating theatre" = OT, "Other" = OtherArea)

Area.summary <- Area.data %>%
  select("COVID-19 zone":"Other") %>% 
  t(.) %>% 
  as.data.frame()

Area.summary <- cbind(Area.summary, Total = rowSums(Area.summary))
Area.summary <- Area.summary %>% 
  subset(., select = Total) %>% 
  rownames_to_column(., "Area")
names(Area.summary)[names(Area.summary) == "Total"] <- "Frequency"
Area.summary <- Area.summary[order(Area.summary$Frequency, decreasing = FALSE),]
Area.summary$Area <- factor(Area.summary$Area, levels = Area.summary$Area)
Area.summary <- Area.summary %>% mutate(Percentage = Frequency/sum(hcovidfull$contactCOVID == "Yes"))

##barchart of Location of clinical contact --> eFigure 1
Area.graph = Area.summary %>%
  ggplot(aes(x = `Area`, y = Percentage)) + 
  geom_col(fill = "#1B9E77", colour = "black") +
  geom_text(aes(label = scales::percent(Percentage, accuracy = 1)), position = position_dodge(width = 1), hjust = -0.2, colour = "black", size = 5, fontface='bold') +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1), expand = c(0, 0), limits = c(0, 0.53)) +
  labs(x = "Area of clinical contact", y = "% of all clinical contact with suspected/confirmed COVID-19") +
  coord_flip() +
  theme(plot.title = element_text(size = 20, face="bold"),
        axis.line = element_line(colour = "black"),
        axis.text = element_text(size=14, face="bold"),
        axis.title = element_text(size=18,face="bold"),
        panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank())
print(Area.graph)


##df formation for AGPType
AGP.data <- hcovidfull %>% 
  select("S_ID", "Bronchoscopy/ENT":"OtherAGP") %>% 
  na.omit(.)
AGP.data$`AGP Total` <- rowSums(AGP.data[-1] == TRUE)
AGP.data <- AGP.data %>% 
  rename("Bronch and ENT procedures" = `Bronchoscopy/ENT`, "Intubation/Extubation" = IntubationExtubation, "Surgery and post-mortem" = Surgery, "Induction of sputum" = Sputum, "Endoscopy" = EndoscopyAGP, "Other" = OtherAGP)

AGP.summary <- AGP.data %>%
  select("Bronch and ENT procedures":"Other") %>% 
  t(.) %>% 
  as.data.frame()

AGP.summary <- cbind(AGP.summary, Total = rowSums(AGP.summary))
AGP.summary <- AGP.summary %>% 
  subset(., select = Total) %>% 
  rownames_to_column(., "AGP Type")
names(AGP.summary)[names(AGP.summary) == "Total"] <- "Frequency"
AGP.summary <- AGP.summary[order(AGP.summary$Frequency, decreasing = FALSE),]
AGP.summary$`AGP Type` <- factor(AGP.summary$`AGP Type`, levels = AGP.summary$`AGP Type`)
AGP.summary <- AGP.summary %>% mutate(Percentage = Frequency/sum(hcovidfull$AGPExpo == "Yes"))

##barchart of AGP Type --> eFigure 2
AGP.graph = AGP.summary %>%
  ggplot(aes(x = `AGP Type`, y = Percentage)) + 
  geom_col(fill = "#1B9E77", colour = "black") +
  geom_text(aes(label = scales::percent(Percentage, accuracy = 1)), position = position_dodge(width = 1), hjust = -0.2, colour = "black", size = 5, fontface='bold') +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1), expand = c(0, 0), limits = c(0, 0.83)) +
  labs(x = "AGP", y = "% of all clinical contact with suspected/confirmed COVID-19 involving AGP(s)") +
  coord_flip() +
  theme(plot.title = element_text(size = 20, face="bold"),
        axis.line = element_line(colour = "black"),
        axis.text = element_text(size=14, face="bold"),
        axis.title = element_text(size=18,face="bold"),
        axis.title.x=element_text(hjust = 2.0),
        panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank())
print(AGP.graph)


##df formation for Symptoms during Self-Isolation
SISymptoms.data <- hcovidfull %>% 
  select("S_ID", "Fever":"No symptoms") %>% 
  na.omit(.)
SISymptoms.data$`Symptoms Total` <- ifelse(SISymptoms.data$`No symptoms` == FALSE, rowSums(SISymptoms.data[-1] == TRUE), 0)

SISymptoms.summary <- SISymptoms.data %>%
  select("Fever":"No symptoms") %>% 
  t(.) %>% 
  as.data.frame()

SISymptoms.summary <- cbind(SISymptoms.summary, Total = rowSums(SISymptoms.summary))
SISymptoms.summary <- SISymptoms.summary %>% 
  subset(., select = Total) %>% 
  rownames_to_column(., "Symptoms")
names(SISymptoms.summary)[names(SISymptoms.summary) == "Total"] <- "Frequency"
SISymptoms.summary <- SISymptoms.summary[order(SISymptoms.summary$`Frequency`, decreasing = FALSE),]
SISymptoms.summary$Symptoms <- factor(SISymptoms.summary$Symptoms, levels = SISymptoms.summary$Symptoms)
SISymptoms.summary <- SISymptoms.summary %>% mutate(Percentage = Frequency/sum(hcovidfull$SelfIso == "Yes"))

SISymptoms.cumulcount = count(SISymptoms.data, `Symptoms Total`) #SISymptoms Count Table

##barchart of SISymptoms --> eFigure 3
SISymptoms.graph = SISymptoms.summary %>%
  ggplot(aes(x = `Symptoms`, y = Percentage)) + 
  geom_col(fill = "#1B9E77", colour = "black") +
  geom_text(aes(label = scales::percent(Percentage, accuracy = 1)), position = position_dodge(width = 1), hjust = -0.2, colour = "black", size = 5, fontface='bold') +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1), expand = c(0, 0), limits = c(0, 1.05)) +
  labs(x = "Symptoms during self-isolation", y = "% of all who self-isolated") +
  coord_flip() +
  theme(plot.title = element_text(size = 20, face="bold"),
        axis.line = element_line(colour = "black"),
        axis.text = element_text(size=14, face="bold"),
        axis.title = element_text(size=18,face="bold"),
        panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank())
print(SISymptoms.graph)


##df formation for NoPPEreason
noPPEreason.data <- hcovidfull %>% 
  select("S_ID", "Clinical reason":"OtherReason") %>% 
  na.omit(.)
noPPEreason.data$`No PPE reason` <- rowSums(noPPEreason.data[-1] == TRUE)
noPPEreason.data <- noPPEreason.data %>% 
  rename("Clinical" = `Clinical reason`, "Other" = OtherReason)

noPPEreason.summary <- noPPEreason.data %>%
  select("Clinical":"Other") %>% 
  t(.) %>% 
  as.data.frame()

noPPEreason.summary <- cbind(noPPEreason.summary, Total = rowSums(noPPEreason.summary))
noPPEreason.summary <- noPPEreason.summary %>% 
  subset(., select = Total) %>% 
  rownames_to_column(., 'Reason for inadequate PPE')
names(noPPEreason.summary)[names(noPPEreason.summary) == "Total"] <- "Frequency"
noPPEreason.summary <- noPPEreason.summary[order(noPPEreason.summary$`Frequency`, decreasing = FALSE),]
noPPEreason.summary$`Reason for inadequate PPE` <- factor(noPPEreason.summary$`Reason for inadequate PPE`, levels = noPPEreason.summary$`Reason for inadequate PPE`)
noPPEreason.summary <- noPPEreason.summary %>% mutate(Percentage = Frequency/sum(hcovidfull$NoPPEexpo == "Yes"))

##barchart of noPPEreason --> eFigure 4
noPPEreason.graph = noPPEreason.summary %>% 
  ggplot(aes(x = `Reason for inadequate PPE`, y = Percentage)) + 
  geom_col(fill = "#1B9E77", colour = "black") +
  geom_text(aes(label = scales::percent(Percentage, accuracy = 1)), position = position_dodge(width = 1), hjust = -0.2, colour = "black", size = 5, fontface='bold') +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1), expand = c(0, 0), limits = c(0, 0.83)) +
  labs(x = "Reason for inadequate PPE", y = "% of participants using inadequate PPE") +
  coord_flip() +
  theme(plot.title = element_text(size = 20, face="bold"),
        axis.line = element_line(colour = "black"),
        axis.text = element_text(size=14, face="bold"),
        axis.title = element_text(size=18,face="bold"),
        panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank())
print(noPPEreason.graph)


#TIME OUT
facilityoutcomes.graph #Figure 2
LackPPEItems.graph #Figure 3

Area.graph #eFigure 1
AGP.graph #eFigure 2
SISymptoms.graph #eFigure 3
noPPEreason.graph #eFigure 4


#DEFORMATION