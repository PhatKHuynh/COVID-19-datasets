#START UP
library(tidyverse)
library(lubridate) #datesandtimes
library(ggplot2) #graphical interrogation PRN
library(visdat) #missingness visualisation PRN
library(naniar) #missingness visualisation PRN


#Load data
hcovidraw <- read.csv("R:\\Research\\Corona-19\\updated_data\\COVID_healthcare_UK\\Raw_Dataset_(Deidentified)_with_R_Code_(Revised)\\hcovidraw.csv", header = TRUE, stringsAsFactors = FALSE, na.strings=c(""," "))


#Tuning
##drop useless columns (i.e. "Future E-mails")
hcovidraw$Future.E.mails <- NULL
hcovidraw$SelfIsoStat_N <- NULL
hcovidraw$CoVStat_N <- NULL

##rename columns
hcovidraw <- hcovidraw %>%
  rename(S_Auto = �..S_Auto, Date = Completion.Date, GenderMatch = Gender_yn, OGender = O...Gender, 
         EthnicMain = Ethnic.Group.Main, EthnicAABB = Ethnic.Group.AABB, EthnicBABBC = Ethnic.Group.BABBC,
         EthnicMMeg = Ethnic.Group.MMeg, EthnicW = Ethnic.Group.W,
         EthnicA = Ethnic.Group.A, OEthnic = O...Ethnic, hChildren = hChildren_yn, Facility = Main.Healthcare.Facility,
         PSMinor = Primary.Specialty_Simple, PSDoc = Primary.Specialty_Doc,
         SelfIso = Self.iso.ever_yn, SIDuration = Self.iso.Duration, OSIT = O...Self.iso_T,
         SIMulti = Self.iso.multiple_yn, SISymptoms = sCOVID.19.symptoms,
         Hospitalised = sHospitalisation_yn, selfTest = sCOVID.Test.Pos.,
         PublicTransport = Travel...Public_yn, contactCOVID = COVID.19.Contact_yn,
         Area = Area.Location, AGPExpo = AGP.Exposure_yn, AGPType = AGP.Type,
         PPETraining = PPE.Training, PPELack = PPE.Lacked.Access_yn, PPELackItems = PPE.Lacked.Access.Items,
         NoPPEexpo = Lack.PPEexpo_yn, NoPPEexpofreq = Lack.PPEexpo.Freq, NoPPEreason = Lack.PPEexpo.Reason,
         ReusePPE = PPE.Reuse_yn, CustomPPE = PPE.Custom_yn, OtherComments = Other.Comments)

##lubridate date&time
hcovidraw$Date <- dmy_hm(hcovidraw$Date)

##combine Ethnic Subgroups; combine Primary Specialties
hcovidraw <- hcovidraw %>% 
  unite(EthnicSub, EthnicAABB:EthnicA, remove = TRUE, na.rm = TRUE) %>% 
  unite(Specialty, PSMinor:PSDoc, remove = FALSE, na.rm = TRUE)

##fine-tune Smoker
hcovidraw$Smoker[is.na(hcovidraw$Smoker)] <- "Prefer not to say"

##fine-tune Role
hcovidraw <- hcovidraw %>% 
  mutate(RoleGroup = case_when(
    Role == "Doctor" ~ "Doctors",
    Role == "Dentist" | Role == "Dental Nurse" | Role == "Dental Hygienist" ~ "Dentists and dental staff",
    Role == "Healthcare Assistant (HCA)" | Role == "Maternity Care Worker" | Role == "Midwife" | Role == "Nurse" | Role == "Nursing Associate" ~ "Nurses, midwives and associated staff",
    Role == "Dietician" | Role == "Healthcare Scientist (e.g. lab-based)" | Role == "Occupational Therapist (OT)" | Role == "Operating Department Practitioner (ODP)" | Role == "Optician" | Role == "Paramedic" | Role == "Pharmacist" | Role == "Phlebotomist" | Role == "Physician Associate" | Role == "Physiotherapist" | Role == "Psychologist" | Role == "Radiographer" | Role == "Speech and Language Therapist (SaLT)" | Role == "Technician (Clinical)" | Role == "Therapist (Other)" ~ "AHPs",
    Role == "Administrative Staff" | Role == "Domestic Services" | Role == "Manager (Care Home)" | Role == "OTHER" | Role == "Porter" | Role == "Senior Carer (Care Home)" | Role == "Support Worker/Assistant" | Role == "Wellbeing/Activity Coordinator (Care Home)" ~ "Other"))

##fine-tune SIDuration
hcovidraw$SIDuration <- as.factor(hcovidraw$SIDuration)
hcovidraw <- hcovidraw %>%
  mutate(SIDuration = recode(SIDuration, `8 to 14 days ` = "8 to 14 days")) %>% 
  mutate(SIDurationLow = case_when(
    SIDuration == "1 to 7 days" ~ "1",
    SIDuration == "8 to 14 days" ~ "8",
    SIDuration == "More than 14 days" ~ paste(OSIT)
  )) %>% 
  mutate(SIDurationHigh = case_when(
    SIDuration == "1 to 7 days" ~ "7",
    SIDuration == "8 to 14 days" ~ "14",
    SIDuration == "More than 14 days" ~ paste(OSIT)
))
hcovidraw$SIDurationLow <- as.numeric(hcovidraw$SIDurationLow)
hcovidraw$SIDurationHigh <- as.numeric(hcovidraw$SIDurationHigh)

##fine-tune COVID-19 testing
hcovidraw <- hcovidraw %>% 
  mutate(selfTest = recode(selfTest, `No - I have NOT tested positive (tests all negative)` = "No - I have NOT tested positive")) %>%
  mutate(selfTest = recode(selfTest, `No - I have NOT tested positive (e.g. tests all negative, awaiting results)` = "No - I have NOT tested positive")) %>%
  mutate(Test.NoTest = case_when(
    selfTest == "Yes - Oral/Nasal swab" ~ "Tested",
    selfTest == "Yes - Blood test" ~ "Tested",
    selfTest == "No - I have NOT tested positive" ~ "Tested",
    selfTest == "No - I have NEVER BEEN tested" ~ "Untested")) %>% 
  mutate(TestOutcome = case_when(
    selfTest == "Yes - Oral/Nasal swab" ~ "Positive",
    selfTest == "Yes - Blood test" ~ "Positive",
    selfTest == "No - I have NOT tested positive" ~ "NotPositive",
    selfTest == "No - I have NEVER BEEN tested" ~ "Untested")) %>%
  mutate(CompSI = SelfIso == "Yes") %>% 
  mutate(CompHosp = Hospitalised == "Yes") %>% 
  mutate(CompPosi = selfTest == "Yes - Oral/Nasal swab" | selfTest == "Yes - Blood test") %>% 
  mutate(CompOut = CompSI == TRUE | CompHosp == TRUE | CompPosi == TRUE)

##fine-tune noPPEexpofreq
hcovidraw$NoPPEexpofreq[is.na(hcovidraw$NoPPEexpofreq)] <- "Never"
hcovidraw$NoPPEexpofreq <- as.factor(hcovidraw$NoPPEexpofreq)
hcovidraw$NoPPEexpofreq <- factor(hcovidraw$NoPPEexpofreq, level = c("Never", "Rarely", "Sometimes", "Often", "Always")) 


#Exclusion deletions
##delete responses AFTER Phase 1 close (n = 3)
hcovidraw <- hcovidraw %>% filter(Date <= ymd_hms("2020-05-25 12:00:00"))

##delete 'pilot' responses (n = 93)
hcovidraw <- hcovidraw %>% filter(S_Auto > 110)

##delete invalid responses
###Note: Trailing comma required for grepl function; alternatively, could use Filter function
hcovidraw <- hcovidraw[!grepl(", NONE of the above", hcovidraw$Comorbidities),]
hcovidraw <- hcovidraw[!grepl(", NONE of the above", hcovidraw$SISymptoms),]
hcovidraw <- hcovidraw[!grepl("Guernsey", hcovidraw$OtherComments),]
hcovidraw <- hcovidraw %>% 
  filter(Age >=18 & Age <= 99) %>% 
  filter (Sex != "Intersex")


#Wrangling
##wrangle EthnicityBAME
hcovidraw <- hcovidraw %>% 
  mutate(EthnicBAME = case_when(
    EthnicMain == "White" ~ "White",
    EthnicMain == "Another ethnic group" ~ "BAME",
    EthnicMain == "Asian or Asian British" ~ "BAME",
    EthnicMain == "Black, African, Black British or Caribbean" ~ "BAME",
    EthnicMain == "Mixed or multiple ethnic groups" ~ "BAME",
    EthnicMain == "Prefer not to say" ~ "Prefer not to say"))
hcovidraw$EthnicBAME <- as.factor(hcovidraw$EthnicBAME)
hcovidraw$EthnicBAME <- factor(hcovidraw$EthnicBAME, level = c("White", "BAME", "Prefer not to say")) 

##wrangle "hChildren"
hcovidraw$hChildren[is.na(hcovidraw$hChildren)] <- "Lives alone"
hcovidraw <- hcovidraw %>% 
  mutate(hChildrenDef = case_when(
    hChildren == "Lives alone" ~ "Lives alone",
    hChildren == "No" ~ "No children",
    hChildren == "Yes" ~ "Has children"
  ))

##wrangle "Comorbidities" (i.e. PMH) --> dummy variables
hcovidraw$Comorbidities[is.na(hcovidraw$Comorbidities)] <- "Prefer not to say"

hcovidraw <- hcovidraw %>%
  mutate(Hypertension = str_detect(Comorbidities, "High blood pressure")) %>%
  mutate(Diabetes = str_detect(Comorbidities, "Diabetes")) %>%
  mutate(Cancer = str_detect(Comorbidities, "Cancer")) %>%
  mutate(`Heart disease` = str_detect(Comorbidities, "Heart disease")) %>%
  mutate(Immunosuppression = str_detect(Comorbidities, "Immunosuppression")) %>%
  mutate(`Respiratory disease` = str_detect(Comorbidities, "Lung disease")) %>% 
  mutate(`Renal disease` = str_detect(Comorbidities, "Kidney disease")) %>%
  mutate(`Liver disease` = str_detect(Comorbidities, "Liver disease")) %>%
  mutate(`Neurological disease` = str_detect(Comorbidities, "Neurological disease")) %>%
  mutate(Obesity = str_detect(Comorbidities, "Obesity")) %>%
  mutate(`No comorbidities` = str_detect(Comorbidities, "NONE of the above")) %>%
  mutate(`Prefer not to say` = Comorbidities == "Prefer not to say") %>% 
  mutate(Comorbidity1 = Hypertension == TRUE | Diabetes == TRUE | Cancer == TRUE | `Heart disease` == TRUE | Immunosuppression == TRUE | `Respiratory disease` == TRUE | `Renal disease` == TRUE | `Liver disease` == TRUE | `Neurological disease` == TRUE | Obesity == TRUE)

hcovidraw <- hcovidraw %>% 
  mutate(ComorbidityTotal = rowSums(subset(hcovidraw, select = c(Hypertension:Obesity)))) %>% 
  mutate(ComorbidityDef = case_when(
    ComorbidityTotal == 0 ~ "None",
    ComorbidityTotal == 1 ~ "One",
    ComorbidityTotal >= 2 ~ "Two or more"))

##wrangle "Region"
hcovidraw <- hcovidraw %>% 
  mutate(London = str_detect(Region, "Greater London"))

##wrangle "Role" --> dummy variables
hcovidraw <- hcovidraw %>% 
  mutate(Dentist = Role == "Dentist") %>% 
  mutate(Doctor = Role == "Doctor") %>%
  mutate(Nurse = Role == "Nurse") %>% 
  mutate(`Nursing Associate` = Role == "Nursing Associate")

##wrangle "SISymptoms" (i.e. Symptoms experienced during self-isolation) --> dummy variables
hcovidraw <- hcovidraw %>%
  mutate(Fever = str_detect(SISymptoms, "Fever")) %>%
  mutate(Cough = str_detect(SISymptoms, "Cough")) %>%
  mutate(Breathlessness = str_detect(SISymptoms, "Breathlessness")) %>%
  mutate(`Sore throat` = str_detect(SISymptoms, "Sore throat")) %>%
  mutate(Headache = str_detect(SISymptoms, "Headache")) %>%
  mutate(Photophobia = str_detect(SISymptoms, "Photophobia")) %>%
  mutate(`Muscle pain` = str_detect(SISymptoms, "Muscle pain")) %>%
  mutate(Fatigue = str_detect(SISymptoms, "Fatigue")) %>%
  mutate(`Nausea/Vomiting` = str_detect(SISymptoms, "Nausea/vomiting")) %>%
  mutate(Diarrhoea = str_detect(SISymptoms, "Diarrhoea")) %>%
  mutate(`Loss of taste` = str_detect(SISymptoms, "Loss of sense of taste")) %>%
  mutate(`Loss of smell` = str_detect(SISymptoms, "Loss of sense of smell")) %>%
  mutate(`No symptoms` = str_detect(SISymptoms, "NONE of the above"))

hcovidraw <- hcovidraw %>% 
  mutate(SISymptomTotal = rowSums(subset(hcovidraw, select = c(Fever:`Loss of smell`))))
hcovidraw$SISymptomTotal[is.na(hcovidraw$SISymptomTotal)] <- 0

##wrangle "Area" (i.e. Area of clinical contact with suspected/confirmed COVID-19) --> dummy variables
hcovidraw <- hcovidraw %>%
  mutate(COVID19zone = str_detect(Area, "COVID-19 pod/bay/ward")) %>%
  mutate(CareHome = str_detect(Area, "Care/Nursing home")) %>%
  mutate(InpClinic = str_detect(Area, "Clinic \\(inpatient")) %>%
  mutate(OutClinic = str_detect(Area, "Clinic \\(outpatient")) %>%
  mutate(DSU = str_detect(Area, "Day case surgery unit")) %>%
  mutate(ED = str_detect(Area, "Emergency department")) %>%
  mutate(EndoscopyArea = str_detect(Area, "Endoscopy unit")) %>%
  mutate(GP = str_detect(Area, "GP practice")) %>%
  mutate(HomeVisits = str_detect(Area, "Home visits")) %>%
  mutate(ICU = str_detect(Area, "Intensive care")) %>%
  mutate(InpWardnonCOVID = str_detect(Area, "Inpatient ward")) %>%
  mutate(Maternity = str_detect(Area,"Maternity unit/Labour ward")) %>%
  mutate(OT = str_detect(Area, "Operating theatre")) %>%
  mutate(Radiology = str_detect(Area, "Radiology")) %>%
  mutate(OtherArea = str_detect(Area, "OTHER"))

hcovidraw <- hcovidraw %>% 
  mutate(HigherRiskArea = COVID19zone == TRUE | DSU == TRUE | ED == TRUE | EndoscopyArea == TRUE | ICU == TRUE | InpWardnonCOVID == TRUE |OT == TRUE) %>% 
  mutate(AreaTotal = rowSums(subset(hcovidraw, select = c(COVID19zone:OtherArea))))
hcovidraw$AreaTotal[is.na(hcovidraw$AreaTotal)] <- 0
hcovidraw <- hcovidraw %>% mutate(AreaDef = case_when(AreaTotal == 0 ~ "None",
                                                      AreaTotal == 1 ~ "One",
                                                      AreaTotal == 2 ~ "Two",
                                                      AreaTotal >= 3 ~ "Three or more"))

##wrangle "AGPType" (i.e. Type of AGP(s) exposed to) --> dummy variables
hcovidraw <- hcovidraw %>%
  mutate(`Bronchoscopy/ENT` = str_detect(AGPType, "Bronchoscopy and upper ENT airway procedures involving suctioning")) %>%
  mutate(`Dental Procedures` = str_detect(AGPType, "Dental procedures")) %>%
  mutate(CPR = str_detect(AGPType, "Cardiopulmonary resuscitation")) %>%
  mutate(HFNO = str_detect(AGPType, "High flow nasal oxygen")) %>%
  mutate(HFOV = str_detect(AGPType, "High frequency oscillatory ventilation")) %>%
  mutate(Sputum = str_detect(AGPType, "Induction of sputum")) %>%
  mutate(IntubationExtubation = str_detect(AGPType, "Intubation, extubation and related procedures")) %>%
  mutate(Nebulisers = str_detect(AGPType, "Nebulisers")) %>%
  mutate(NIV = str_detect(AGPType, "Non-invasive ventilation")) %>%
  mutate(Surgery = str_detect(AGPType, "Surgery and post mortem procedures")) %>%
  mutate(Tracheostomy = str_detect(AGPType, "Tracheotomy or tracheostomy procedures")) %>%
  mutate(EndoscopyAGP = str_detect(AGPType, "Upper gastro-intestinal endoscopy where there is open suctioning of the upper respiratory tract")) %>%
  mutate(OtherAGP = str_detect(AGPType,"OTHER"))

hcovidraw <- hcovidraw %>% 
  mutate(PHEAGP = `Dental Procedures` == TRUE | HFNO == TRUE | HFOV == TRUE | Sputum == TRUE | IntubationExtubation == TRUE | NIV == TRUE | Surgery == TRUE | Tracheostomy == TRUE | EndoscopyAGP == TRUE) %>% 
  mutate(AGPTotal = rowSums(subset(hcovidraw, select = c(`Dental Procedures`:OtherAGP))))
hcovidraw$AGPTotal[is.na(hcovidraw$AGPTotal)] <- 0
hcovidraw <- hcovidraw %>% mutate(AGPDef = case_when(AGPTotal == 0 ~ "None",
                                                     AGPTotal == 1 ~ "One",
                                                     AGPTotal >= 2 ~ "Two or more"))

##fine-tune composite for clinical contact and AGP exposure
hcovidraw <- hcovidraw %>% 
  mutate(ExposureComp = case_when(contactCOVID == "No" & AGPExpo == "No" ~ "None",
                                  contactCOVID == "Yes" & AGPExpo == "No" ~ "Clinical contact only",
                                  contactCOVID == "No" & AGPExpo == "Yes" ~ "AGP exposure only",
                                  contactCOVID == "Yes" & AGPExpo == "Yes" ~ "Clinical contact and AGP exposure"))

##wrangle "PPELackItems" (i.e. lacked access to PPE items) --> dummy variables
hcovidraw <- hcovidraw %>%
  mutate(Eyewear = str_detect(PPELackItems, "Eye protection")) %>%
  mutate(Hat = str_detect(PPELackItems, "Hat")) %>%
  mutate(Gown = str_detect(PPELackItems, "Gown")) %>%
  mutate(Apron = str_detect(PPELackItems, "Plastic apron")) %>%
  mutate(Gloves = str_detect(PPELackItems, "Gloves")) %>%
  mutate(SurgicalMaskStandard = str_detect(PPELackItems, "Surgical face mask \\(Standard")) %>%
  mutate(SurgicalMaskFR = str_detect(PPELackItems, "Surgical face mask \\(Fluid")) %>%
  mutate(RespiratorMask = str_detect(PPELackItems, "FFP2/FFP3/N95/N100 face mask")) %>%
  mutate(PAPR = str_detect(PPELackItems, "Powered Air Purifying Respiratory"))

hcovidraw <- hcovidraw %>% 
  mutate(PPELackTotal = rowSums(subset(hcovidraw, select = c(Eyewear:PAPR))))
hcovidraw$PPELackTotal[is.na(hcovidraw$PPELackTotal)] <- 0
hcovidraw <- hcovidraw %>% mutate(PPELackDef = case_when(PPELackTotal == 0 ~ "None",
                                                         PPELackTotal == 1 ~ "One",
                                                         PPELackTotal >= 2 ~ "Two or more"))

##wrangle "NoPPEreason" (i.e. reason for not using adequage PPE items) --> dummy variables
hcovidraw <- hcovidraw %>%
  mutate(`Clinical reason` = str_detect(NoPPEreason, "Clinical reasons")) %>%
  mutate(`Lack of adequate PPE training` = str_detect(NoPPEreason, "Lack of adequate PPE training")) %>%
  mutate(`Lack of PPE availability` = str_detect(NoPPEreason, "Lack of PPE availability")) %>%
  mutate(`Patient not suspected/confirmed` = str_detect(NoPPEreason, "Patient not suspected or confirmed COVID-19 at the time")) %>%
  mutate(`Personal choice` = str_detect(NoPPEreason, "Personal choice")) %>%
  mutate(`Senior instruction` = str_detect(NoPPEreason, "Under senior instruction")) %>%
  mutate(OtherReason = str_detect(NoPPEreason, "OTHER"))


#TIME OUT
hcovidfull <- hcovidraw
write.csv(hcovidraw, "R:\\Research\\Corona-19\\updated_data\\COVID_healthcare_UK\\Raw_Dataset_(Deidentified)_with_R_Code_(Revised)\\hcovid_clean.csv", row.names=FALSE)
#save(hcovidraw, file = "data/healthcarecovid.RData")


#DEFORMATION