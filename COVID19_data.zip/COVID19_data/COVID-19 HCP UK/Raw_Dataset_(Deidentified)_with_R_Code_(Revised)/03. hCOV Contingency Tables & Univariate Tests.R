#START UP [Statistical Analyses]
library(tidyverse)
library(reshape2) #might not be needed
library(lubridate) #date and time
library(DescTools) #Tools for Descriptive Statistics and Exploratory Data Analysis
library(epitools) #Epidemiology Tools --> For Odds and Risk Ratios 


#Load data
hcovidfull <- read.csv("data/hcovid_clean.csv", header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)


#Initialise
##convert relevant vectors to factors and re-order/relevel
hcovidfull$EthnicBAME <- as.factor(hcovidfull$EthnicBAME)
hcovidfull$EthnicBAME <- factor(hcovidfull$EthnicBAME, levels = c("White", "BAME", "Prefer not to say"))

hcovidfull$hChildrenDef <- as.factor(hcovidfull$hChildrenDef)
hcovidfull$hChildrenDef <- factor(hcovidfull$hChildrenDef, levels = c("Lives alone", "No children", "Has children"))

hcovidfull$Smoker <- as.factor(hcovidfull$Smoker)
hcovidfull$Smoker <- factor(hcovidfull$Smoker, levels = c("Never smoked", "Current smoker or Ex-smoker (within 1 year)", "Ex-smoker (more than 1 year)", "Prefer not to say")) 

hcovidfull$RoleGroup <- as.factor(hcovidfull$RoleGroup)
hcovidfull$RoleGroup <- relevel(hcovidfull$RoleGroup, "Nurses, midwives and associated staff")

hcovidfull$Grade <- as.factor(hcovidfull$Grade)
hcovidfull$Grade <- relevel(hcovidfull$Grade, "Consultant")

hcovidfull$PSDoc <- as.factor(hcovidfull$PSDoc)
hcovidfull$PSDoc <- relevel(hcovidfull$PSDoc, "Anaesthetics")

hcovidfull$PSMinor <- as.factor(hcovidfull$PSMinor)
hcovidfull$PSMinor <- relevel(hcovidfull$PSMinor, "Medical")

hcovidfull$Facility <- as.factor(hcovidfull$Facility)
hcovidfull$Facility <- relevel(hcovidfull$Facility, "Hospital")

hcovidfull$AreaDef <- as.factor(hcovidfull$AreaDef)
hcovidfull$AreaDef <- factor(hcovidfull$AreaDef, level = c("None", "One", "Two", "Three or more")) 

hcovidfull$AGPDef <- as.factor(hcovidfull$AGPDef)
hcovidfull$AGPDef <- factor(hcovidfull$AGPDef, level = c("None", "One", "Two or more")) 

hcovidfull$NoPPEexpofreq[is.na(hcovidfull$NoPPEexpofreq)] <- "Never"
hcovidfull$NoPPEexpofreq <- as.factor(hcovidfull$NoPPEexpofreq)
hcovidfull$NoPPEexpofreq <- factor(hcovidfull$NoPPEexpofreq, level = c("Never", "Rarely", "Sometimes", "Often", "Always")) 

##data frame formation
hcovidsi <- hcovidfull %>% filter(CompSI == TRUE)
hcovidhosp <- hcovidfull %>% filter(CompHosp == TRUE)
hcovidpos <- hcovidfull %>% filter(CompPosi == TRUE)
hcovidcompout <- hcovidfull %>% filter(CompOut == TRUE)
hcovidtest <- hcovidfull %>% filter(TestOutcome !="Untested") #not required for composites


#function for odds ratio and relevant proportions
fxComp.prop.or <- function(x) {
  cs <<- table(x, hcovidfull$CompOut, useNA = "no")
  propT <<- cs %>% prop.table(margin=1) %>% {. * 100} %>% round(1)
  cs.prop <<- cbind(cs,propT)
  OR = oddsratio.wald(cs, correction = TRUE)
  ORdf <<- as.data.frame(round(OR$measure, digits = 2))
  Chidf <<- as.data.frame(round(OR$p.value, digits = 3))
  ORdf <<- cbind(ORdf, Chidf$chi.square)
  ORdf <<- ORdf %>% 
    rename(OR = estimate, Chi = "Chidf$chi.square") %>% 
    mutate(Significant = Chi < 0.05)
  print(OR$measure)
  print(round(OR$p.value, digits = 3))
}


##Univariate analysis for Age
###glm with Age
Ageglm <- glm(CompOut ~ Age, data = hcovidfull, family = binomial)

###univariate OR and p-value for Age
summary(Ageglm)
exp(coef(Ageglm))
exp(confint(Ageglm))


#Univariate OR Tables
##sociodemographics
###sex
fxComp.prop.or(hcovidfull$Sex)
Sex.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(Sex.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
Sex.csprop <- rownames_to_column(Sex.csprop)

###ethnicmain & BAME
fxComp.prop.or(hcovidfull$EthnicMain)
EthnicMain.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(EthnicMain.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
EthnicMain.csprop <- rownames_to_column(EthnicMain.csprop)

fxComp.prop.or(hcovidfull$EthnicBAME)
EthnicBAME.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(EthnicBAME.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
EthnicBAME.csprop <- rownames_to_column(EthnicBAME.csprop)

###household
fxComp.prop.or(hcovidfull$hHousehold)
hHousehold.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(hHousehold.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
hHousehold.csprop <- rownames_to_column(hHousehold.csprop)

###children
fxComp.prop.or(hcovidfull$hChildren)
hChildren.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(hChildren.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
hChildren.csprop <- rownames_to_column(hChildren.csprop)

###hchildrendef
fxComp.prop.or(hcovidfull$hChildrenDef)
hChildrenDef.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(hChildrenDef.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
hChildrenDef.csprop <- rownames_to_column(hChildrenDef.csprop)


##comorbidities 
###hypertension
fxComp.prop.or(hcovidfull$Hypertension)
Hypertension.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(Hypertension.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
Hypertension.csprop <- rownames_to_column(Hypertension.csprop)

###diabetes
fxComp.prop.or(hcovidfull$Diabetes)
Diabetes.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(Diabetes.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
Diabetes.csprop <- rownames_to_column(Diabetes.csprop)

###cancer
fxComp.prop.or(hcovidfull$Cancer)
Cancer.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(Cancer.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
Cancer.csprop <- rownames_to_column(Cancer.csprop)

###`heart disease`
fxComp.prop.or(hcovidfull$`Heart disease`)
Heartdisease.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(Heartdisease.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
Heartdisease.csprop <- rownames_to_column(Heartdisease.csprop)

###immunosuppression
fxComp.prop.or(hcovidfull$Immunosuppression)
Immunosuppression.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(Immunosuppression.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
Immunosuppression.csprop <- rownames_to_column(Immunosuppression.csprop)

###`respiratory disease`
fxComp.prop.or(hcovidfull$`Respiratory disease`)
Respdisease.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(Respdisease.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
Respdisease.csprop <- rownames_to_column(Respdisease.csprop)

###`renal disease`
fxComp.prop.or(hcovidfull$`Renal disease`)
Renaldisease.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(Renaldisease.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
Renaldisease.csprop <- rownames_to_column(Renaldisease.csprop)

###`liver disease`
fxComp.prop.or(hcovidfull$`Liver disease`)
Liverdisease.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(Liverdisease.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
Liverdisease.csprop <- rownames_to_column(Liverdisease.csprop)

###`neurological disease`
fxComp.prop.or(hcovidfull$`Neurological disease`)
Neurodisease.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(Neurodisease.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
Neurodisease.csprop <- rownames_to_column(Neurodisease.csprop)

###obesity
fxComp.prop.or(hcovidfull$Obesity)
Obesity.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(Obesity.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
Obesity.csprop <- rownames_to_column(Obesity.csprop)

###`prefer not to say`
fxComp.prop.or(hcovidfull$`Prefer not to say`)
Prefernottosay.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(Prefernottosay.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
Prefernottosay.csprop <- rownames_to_column(Prefernottosay.csprop)

###none vs. comorbidities 1 or more
fxComp.prop.or(hcovidfull$ComorbidityDef)
ComorbidityDef.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(ComorbidityDef.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
ComorbidityDef.csprop <- rownames_to_column(ComorbidityDef.csprop)


##smoking status
fxComp.prop.or(hcovidfull$Smoker)
Smoker.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(Smoker.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
Smoker.csprop <- rownames_to_column(Smoker.csprop)


##work details
###country
fxComp.prop.or(hcovidfull$Country)
Country.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(Country.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
Country.csprop <- rownames_to_column(Country.csprop)

###main healthcare facility
fxComp.prop.or(hcovidfull$Facility)
Facility.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(Facility.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
Facility.csprop <- rownames_to_column(Facility.csprop)

###role group
scatter.smooth(jitter(as.numeric(hcovidfull$CompOut)) ~ jitter(as.numeric(hcovidfull$RoleGroup)), family = "gaussian", lpars = list(col = "red"))

fxComp.prop.or(hcovidfull$RoleGroup)
RoleGroup.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(RoleGroup.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
RoleGroup.csprop <- rownames_to_column(RoleGroup.csprop)

###grade
scatter.smooth(jitter(as.numeric(hcovidfull$CompOut)) ~ jitter(as.numeric(hcovidfull$Grade)), family = "gaussian", lpars = list(col = "red"))

fxComp.prop.or(hcovidfull$Grade)
Grade.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(Grade.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
Grade.csprop <- rownames_to_column(Grade.csprop)

###specialty
scatter.smooth(jitter(as.numeric(hcovidfull$CompOut)) ~ jitter(as.numeric(hcovidfull$Specialty)), family = "gaussian", lpars = list(col = "red"))

fxComp.prop.or(hcovidfull$PSDoc) #DOCTORS
PSDoc.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(PSDoc.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
PSDoc.csprop <- rownames_to_column(PSDoc.csprop)

fxComp.prop.or(hcovidfull$PSMinor) #NON-DOCTORS
PSMinor.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(PSMinor.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
PSMinor.csprop <- rownames_to_column(PSMinor.csprop)

fxComp.prop.or(hcovidfull$Specialty) #ALL SPECIALTIES
Specialty.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(Specialty.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
Specialty.csprop <- rownames_to_column(Specialty.csprop)


##exposure risk
###use of public transport
fxComp.prop.or(hcovidfull$PublicTransport)
PublicTransport.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(PublicTransport.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
PublicTransport.csprop <- rownames_to_column(PublicTransport.csprop)

###regular contact with suspected/confirmed COVID-19
fxComp.prop.or(hcovidfull$contactCOVID)
contactCOVID.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(contactCOVID.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
contactCOVID.csprop <- rownames_to_column(contactCOVID.csprop)

###regular exposure to AGP in suspected/confirmed COVID-19
fxComp.prop.or(hcovidfull$AGPExpo)
AGPExpo.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(AGPExpo.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
AGPExpo.csprop <- rownames_to_column(AGPExpo.csprop)


##PPE
###sufficient training in PPE practice
fxComp.prop.or(hcovidfull$PPETraining)
PPETraining.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(PPETraining.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
PPETraining.csprop <- rownames_to_column(PPETraining.csprop)

###lacked access to ppe
fxComp.prop.or(hcovidfull$PPELack)
PPELack.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(PPELack.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
PPELack.csprop <- rownames_to_column(PPELack.csprop)

###inadequate ppe exposure
fxComp.prop.or(hcovidfull$NoPPEexpo)
NoPPEexpo.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(NoPPEexpo.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
NoPPEexpo.csprop <- rownames_to_column(NoPPEexpo.csprop)

###frequency of inadequate ppe exposure
fxComp.prop.or(hcovidfull$NoPPEexpofreq)
NoPPEexpofreq.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(NoPPEexpofreq.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
NoPPEexpofreq.csprop <- rownames_to_column(NoPPEexpofreq.csprop)

###reusing PPE
fxComp.prop.or(hcovidfull$ReusePPE)
ReusePPE.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(ReusePPE.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
ReusePPE.csprop <- rownames_to_column(ReusePPE.csprop)

###customised PPE
fxComp.prop.or(hcovidfull$CustomPPE)
CustomPPE.csprop <- cbind(as.data.frame(cs.prop), ORdf)
colnames(CustomPPE.csprop) <- c("FALSE (n)", "TRUE (n)", "FALSE (%)", "TRUE (%)", "OR", "lower", "upper", "chi", "sig")
CustomPPE.csprop <- rownames_to_column(CustomPPE.csprop)


#TIME OUT


#DEFORMATION