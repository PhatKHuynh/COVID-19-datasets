# Read data from Excel file
df = read.csv("R:\\Research\\Corona-19\\Updated_data\\COVID_healthcare_UK\\Raw_Dataset_(Deidentified)_with_R_Code_(Revised)\\clean_covid_data.csv",)
COVID_data = as.data.frame(df);
dt = sort(sample(nrow(COVID_data), nrow(COVID_data)*.7))
train <- COVID_data[dt,]
test <- COVID_data[-dt,]
logitmod <- glm(COVID_exp ~ Age + Cancer + Resp + Obes + Smoker + Doctor + Allied_prof + Dental_staff + Pub_trans + C_contact 
                + AGP + PPE_train + Lacked_PPE + cont_wo_PPE + Imp_PPE, family=binomial, COVID_data)
summary(logitmod)

logitmod1 <- glm(COVID_exp ~ 1, family=binomial, COVID_data)
summary(logitmod1)
anova(logitmod, logitmod1, test ="Chisq")
library(lmtest)
lrtest(logitmod, logitmod1)

#k-fold validation
library(ggplot2)
library(caret)
ctrl <- trainControl(method = "repeatedcv", number = 10, savePredictions = TRUE)
pred = predict(logitmod, newdata=test)
confusionMatrix(data=pred, test$COVID_exp)
